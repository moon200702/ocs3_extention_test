#!/bin/bash
set -Eeuo pipefail

APP_DIR=/app/ocsinventory-backend
PYTHON=/app/ocs-venv/bin/python
UWSGI=/app/ocs-venv/bin/uwsgi

cd "$APP_DIR"

echo "[erpassets] syncing extension manifest"
"$PYTHON" manage.py shell -c '
from extension.sync import sync_extensions_from_filesystem
sync_extensions_from_filesystem()
'

echo "[erpassets] enabling extension"
"$PYTHON" manage.py shell -c '
from extension.models import Extension
obj = Extension.objects.get(django_app="erpassets")
if not obj.enabled:
    obj.enabled = True
    obj.save(update_fields=["enabled"])
    print("[erpassets] enabled")
else:
    print("[erpassets] already enabled")
'

echo "[erpassets] starting uWSGI"
exec "$UWSGI" --ini /app/uwsgi.ini
