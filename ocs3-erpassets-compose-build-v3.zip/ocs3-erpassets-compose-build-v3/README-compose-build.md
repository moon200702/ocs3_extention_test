# OCS Inventory 3 RC2 + ERP Assets build overlay

This overlay makes the ERP extension part of the Docker images instead of relying on runtime bind mounts or manual `docker exec` installation steps.

## Expected project layout

Copy these files into the same OCS project directory that already contains:

- `files/nginx/ocsinventory-backend.conf`
- your `.env` if used

Result:

```text
ocsinventory-server-3/
├── docker-compose.yml
├── docker/
│   ├── backend/
│   │   ├── Dockerfile
│   │   └── start-erpassets.sh
│   └── frontend/
│       └── Dockerfile
├── extensions/
│   ├── backend/erpassets/
│   └── frontend/erpassets/
└── files/nginx/ocsinventory-backend.conf
```

## Build and start

```bash
sudo docker compose config
sudo docker compose build --no-cache ocsinventory-backend ocsinventory-frontend
sudo docker compose up -d
```

The backend startup order is:

1. upstream `/entrypoint.sh`
2. activate `/app/ocs-venv`
3. upstream `python manage.py migrate`
4. `start-erpassets`
5. sync `extension.json`
6. set `erpassets.enabled=True`
7. start uWSGI with `/app/uwsgi.ini`

The frontend extension is copied into the image at:

`/usr/share/ocsinventory-frontend/extensions/erpassets/`

The old named volume `ocsinventory-frontend-extensions` is intentionally removed because mounting a volume over `/usr/share/ocsinventory-frontend/extensions` would hide the extension baked into the image.

## Verify

```bash
sudo docker compose ps
sudo docker logs --tail=200 ocsinventory-backend
sudo docker exec ocsinventory-backend \
  /app/ocs-venv/bin/python /app/ocsinventory-backend/manage.py showmigrations erpassets

sudo docker exec ocsinventory-backend \
  /app/ocs-venv/bin/python /app/ocsinventory-backend/manage.py shell -c \
  'from extension.models import Extension; print(list(Extension.objects.filter(django_app="erpassets").values()))'

sudo docker exec ocsinventory-frontend \
  find /usr/share/ocsinventory-frontend/extensions/erpassets -maxdepth 2 -type f -print
```

For RC2, the upstream backend image healthcheck may still report unhealthy because it curls `localhost:8000` while the deployment uses the uWSGI Unix socket. Check the uWSGI socket/proxy and logs rather than relying on that health flag alone.
