from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("erpassets", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="erpasset",
            name="reported_ocs_asset",
            field=models.CharField(blank=True, default="", max_length=255),
        ),
        migrations.AddField(
            model_name="erpasset",
            name="reported_ocs_serial",
            field=models.CharField(blank=True, default="", max_length=255),
        ),
        migrations.AddField(
            model_name="erpasset",
            name="reconciliation_status",
            field=models.CharField(blank=True, default="unknown", max_length=50),
        ),
    ]
