from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ("inventory_base", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="ERPAsset",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("asset_no", models.CharField(max_length=100, unique=True)),
                ("erp_serial", models.CharField(blank=True, default="", max_length=255)),
                ("department", models.CharField(blank=True, default="", max_length=255)),
                ("custodian", models.CharField(blank=True, default="", max_length=255)),
                ("location", models.CharField(blank=True, default="", max_length=255)),
                ("status", models.CharField(blank=True, default="", max_length=100)),
                ("source_system", models.CharField(blank=True, default="ERP", max_length=100)),
                ("source_id", models.CharField(blank=True, default="", max_length=255)),
                ("raw_data", models.JSONField(blank=True, default=dict)),
                ("last_sync", models.DateTimeField(auto_now=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("asset", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="erp_asset_record", to="inventory_base.inventorybase")),
            ],
            options={"ordering": ["asset_no"]},
        ),
        migrations.CreateModel(
            name="ERPComponent",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("component_type", models.CharField(max_length=100)),
                ("slot", models.CharField(blank=True, default="", max_length=100)),
                ("manufacturer", models.CharField(blank=True, default="", max_length=255)),
                ("model", models.CharField(blank=True, default="", max_length=255)),
                ("erp_asset_no", models.CharField(blank=True, default="", max_length=100)),
                ("erp_serial", models.CharField(blank=True, default="", max_length=255)),
                ("observed_serial", models.CharField(blank=True, default="", max_length=255)),
                ("match_status", models.CharField(choices=[("matched", "Matched"), ("mismatch", "Mismatch"), ("erp_only", "ERP only"), ("ocs_only", "OCS only"), ("unknown", "Unknown")], default="unknown", max_length=20)),
                ("source_id", models.CharField(blank=True, default="", max_length=255)),
                ("raw_data", models.JSONField(blank=True, default=dict)),
                ("last_sync", models.DateTimeField(auto_now=True)),
                ("erp_asset", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="components", to="erpassets.erpasset")),
            ],
            options={"ordering": ["erp_asset", "component_type", "slot", "id"]},
        ),
        migrations.CreateModel(
            name="MaintenanceEvent",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("external_id", models.CharField(max_length=255)),
                ("event_type", models.CharField(blank=True, default="maintenance", max_length=100)),
                ("opened_at", models.DateTimeField(blank=True, null=True)),
                ("closed_at", models.DateTimeField(blank=True, null=True)),
                ("problem", models.TextField(blank=True, default="")),
                ("action", models.TextField(blank=True, default="")),
                ("vendor", models.CharField(blank=True, default="", max_length=255)),
                ("technician", models.CharField(blank=True, default="", max_length=255)),
                ("old_serial", models.CharField(blank=True, default="", max_length=255)),
                ("new_serial", models.CharField(blank=True, default="", max_length=255)),
                ("component_asset_no", models.CharField(blank=True, default="", max_length=100)),
                ("status", models.CharField(blank=True, default="", max_length=100)),
                ("raw_data", models.JSONField(blank=True, default=dict)),
                ("last_sync", models.DateTimeField(auto_now=True)),
                ("erp_asset", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="maintenance_events", to="erpassets.erpasset")),
            ],
            options={"ordering": ["-opened_at", "-id"]},
        ),
        migrations.AddConstraint(
            model_name="maintenanceevent",
            constraint=models.UniqueConstraint(fields=("erp_asset", "external_id"), name="unique_erpassets_maintenance_external_id"),
        ),
    ]
