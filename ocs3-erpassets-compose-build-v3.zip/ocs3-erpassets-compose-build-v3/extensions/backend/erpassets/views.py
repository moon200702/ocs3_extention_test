from django.db import transaction
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.response import Response

from asset.inventory_base.models import InventoryBase
from permission.permissions import DefaultModelPermissions

from .config import public_config
from .models import ERPAsset, ERPComponent, MaintenanceEvent
from .serializer import (
    ERPAssetSerializer,
    ERPComponentSerializer,
    MaintenanceEventSerializer,
)


def _norm_serial(value):
    return (value or "").strip().upper()


class ERPAssetViewSet(viewsets.ModelViewSet):
    permission_classes = [DefaultModelPermissions]
    serializer_class = ERPAssetSerializer
    queryset = ERPAsset.objects.select_related("asset").all()
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = [
        "asset_no",
        "erp_serial",
        "department",
        "custodian",
        "location",
        "status",
        "asset__name",
        "asset__serial",
        "asset__uuid",
    ]
    ordering_fields = ["id", "asset_no", "last_sync", "created_at"]

    def get_queryset(self):
        qs = super().get_queryset()
        asset_id = self.request.query_params.get("asset")
        asset_no = self.request.query_params.get("asset_no")
        if asset_id:
            qs = qs.filter(asset_id=asset_id)
        if asset_no:
            qs = qs.filter(asset_no=asset_no)
        return qs

    @action(detail=False, methods=["get"], url_path="integration-config")
    def integration_config(self, request):
        """Expose non-secret ERP adapter settings for the demo frontend."""
        return Response(public_config())

    @action(detail=False, methods=["get"], url_path="by-asset")
    def by_asset(self, request):
        asset_id = request.query_params.get("asset_id")
        if not asset_id:
            return Response(
                {"error": "asset_id is required"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        record = (
            ERPAsset.objects
            .select_related("asset")
            .filter(asset_id=asset_id)
            .first()
        )
        if not record:
            return Response({}, status=status.HTTP_404_NOT_FOUND)

        payload = ERPAssetSerializer(record).data
        payload["components"] = ERPComponentSerializer(
            record.components.all(), many=True
        ).data
        payload["maintenance_events"] = MaintenanceEventSerializer(
            record.maintenance_events.all()[:50], many=True
        ).data
        return Response(payload)

    @action(detail=False, methods=["post"], url_path="upsert-by-serial")
    def upsert_by_serial(self, request):
        """
        External ERP-friendly endpoint.

        Minimal request (aligned with the ERP demo API):
        {
          "property_number": "PROP-2026-0001",
          "ocs_serial": "OCS-SN-12345678",
          "erp_serial": "ERP-SN-87654321",
          "reconciliation_status": "matched"
        }

        Backward-compatible aliases `asset_no` and `serial` are also accepted.
        OCS core inventory is NOT modified.
        """
        ocs_serial = _norm_serial(
            request.data.get("ocs_serial") or request.data.get("serial")
        )
        asset_no = str(
            request.data.get("property_number") or request.data.get("asset_no") or ""
        ).strip()

        if not ocs_serial or not asset_no:
            return Response(
                {"error": "property_number/asset_no and ocs_serial/serial are required"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Match the OCS identity using the ERP-reported OCS serial. ERP serial
        # is a separate ERP-side identifier and is not used for OCS matching.
        candidates = list(
            InventoryBase.objects.filter(serial__iexact=ocs_serial)[:3]
        )
        if len(candidates) == 0:
            return Response(
                {
                    "error": "No OCS asset matches this serial",
                    "ocs_serial": ocs_serial,
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        if len(candidates) > 1:
            return Response(
                {
                    "error": "Multiple OCS assets match this serial; manual reconciliation required",
                    "ocs_serial": ocs_serial,
                    "asset_ids": [x.id for x in candidates],
                },
                status=status.HTTP_409_CONFLICT,
            )

        asset = candidates[0]

        defaults = {
            "erp_serial": str(request.data.get("erp_serial") or "").strip(),
            "reported_ocs_asset": str(request.data.get("ocs_asset") or "").strip(),
            "reported_ocs_serial": ocs_serial,
            "reconciliation_status": str(request.data.get("reconciliation_status") or "unknown").strip(),
            "department": str(request.data.get("department") or "").strip(),
            "custodian": str(request.data.get("custodian") or "").strip(),
            "location": str(request.data.get("location") or "").strip(),
            "status": str(request.data.get("status") or "").strip(),
            "source_system": str(
                request.data.get("source_system") or "ERP"
            ).strip(),
            "source_id": str(request.data.get("source_id") or asset_no).strip(),
            "raw_data": request.data.get("raw_data") or dict(request.data),
        }

        with transaction.atomic():
            # Keep asset_no unique. If it already exists, move/update the same
            # ERP identity instead of silently creating a second record.
            record = ERPAsset.objects.select_for_update().filter(
                asset_no=asset_no
            ).first()

            created = record is None
            if record is None:
                record = ERPAsset(asset=asset, asset_no=asset_no)
            else:
                record.asset = asset

            for key, value in defaults.items():
                setattr(record, key, value)
            record.save()

        response_status = (
            status.HTTP_201_CREATED if created else status.HTTP_200_OK
        )
        return Response(
            ERPAssetSerializer(record).data,
            status=response_status,
        )


class ERPComponentViewSet(viewsets.ModelViewSet):
    permission_classes = [DefaultModelPermissions]
    serializer_class = ERPComponentSerializer
    queryset = ERPComponent.objects.select_related("erp_asset").all()
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = [
        "component_type",
        "slot",
        "manufacturer",
        "model",
        "erp_asset_no",
        "erp_serial",
        "observed_serial",
        "match_status",
        "erp_asset__asset_no",
    ]
    ordering_fields = ["id", "component_type", "slot", "last_sync"]

    def get_queryset(self):
        qs = super().get_queryset()
        erp_asset = self.request.query_params.get("erp_asset")
        asset_no = self.request.query_params.get("asset_no")
        if erp_asset:
            qs = qs.filter(erp_asset_id=erp_asset)
        if asset_no:
            qs = qs.filter(erp_asset__asset_no=asset_no)
        return qs


class MaintenanceEventViewSet(viewsets.ModelViewSet):
    permission_classes = [DefaultModelPermissions]
    serializer_class = MaintenanceEventSerializer
    queryset = MaintenanceEvent.objects.select_related("erp_asset").all()
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = [
        "external_id",
        "event_type",
        "problem",
        "action",
        "vendor",
        "technician",
        "old_serial",
        "new_serial",
        "component_asset_no",
        "status",
        "erp_asset__asset_no",
    ]
    ordering_fields = ["id", "opened_at", "closed_at", "last_sync"]

    def get_queryset(self):
        qs = super().get_queryset()
        erp_asset = self.request.query_params.get("erp_asset")
        asset_no = self.request.query_params.get("asset_no")
        if erp_asset:
            qs = qs.filter(erp_asset_id=erp_asset)
        if asset_no:
            qs = qs.filter(erp_asset__asset_no=asset_no)
        return qs
