from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    ERPAssetViewSet,
    ERPComponentViewSet,
    MaintenanceEventViewSet,
)

router = DefaultRouter()
router.register(r"assets", ERPAssetViewSet, basename="erpasset")
router.register(r"components", ERPComponentViewSet, basename="erpcomponent")
router.register(r"maintenance", MaintenanceEventViewSet, basename="maintenanceevent")

urlpatterns = [
    path("", include(router.urls)),
]
