default_app_config = "extensions.erpassets.apps.ErpassetsConfig"
