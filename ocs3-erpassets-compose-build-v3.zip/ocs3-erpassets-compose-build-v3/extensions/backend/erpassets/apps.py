import logging

from django.apps import AppConfig

logger = logging.getLogger("extensions.erpassets")


class ErpassetsConfig(AppConfig):
    """OCS3 extension application configuration."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "extensions.erpassets"
    verbose_name = "ERP Asset Integration"
