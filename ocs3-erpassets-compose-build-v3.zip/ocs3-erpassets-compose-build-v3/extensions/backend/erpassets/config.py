import json
import os
from pathlib import Path

_CONFIG_PATH = Path(__file__).resolve().parent / "config.json"


def load_config():
    data = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    if os.getenv("ERP_API_BASE_URL"):
        data["base_url"] = os.environ["ERP_API_BASE_URL"].strip()
    if os.getenv("ERP_ASSETS_ENDPOINT"):
        data["assets_endpoint"] = os.environ["ERP_ASSETS_ENDPOINT"].strip()
    return data


def public_config():
    config = load_config()
    return {
        "base_url": config.get("base_url", ""),
        "assets_endpoint": config.get("assets_endpoint", ""),
        "timeout_seconds": config.get("timeout_seconds", 10),
        "mapping": config.get("mapping", {}),
    }
