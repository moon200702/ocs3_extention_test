from django.db import models


class ERPAsset(models.Model):
    asset = models.OneToOneField(
        "inventory_base.InventoryBase",
        on_delete=models.CASCADE,
        related_name="erp_asset_record",
    )
    asset_no = models.CharField(max_length=100, unique=True)
    erp_serial = models.CharField(max_length=255, blank=True, default="")
    reported_ocs_asset = models.CharField(max_length=255, blank=True, default="")
    reported_ocs_serial = models.CharField(max_length=255, blank=True, default="")
    reconciliation_status = models.CharField(max_length=50, blank=True, default="unknown")
    department = models.CharField(max_length=255, blank=True, default="")
    custodian = models.CharField(max_length=255, blank=True, default="")
    location = models.CharField(max_length=255, blank=True, default="")
    status = models.CharField(max_length=100, blank=True, default="")
    source_system = models.CharField(max_length=100, blank=True, default="ERP")
    source_id = models.CharField(max_length=255, blank=True, default="")
    raw_data = models.JSONField(default=dict, blank=True)
    last_sync = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["asset_no"]

    def __str__(self):
        return f"{self.asset_no} -> asset #{self.asset_id}"


class ERPComponent(models.Model):
    MATCH_CHOICES = [
        ("matched", "Matched"),
        ("mismatch", "Mismatch"),
        ("erp_only", "ERP only"),
        ("ocs_only", "OCS only"),
        ("unknown", "Unknown"),
    ]

    erp_asset = models.ForeignKey(
        ERPAsset,
        on_delete=models.CASCADE,
        related_name="components",
    )
    component_type = models.CharField(max_length=100)
    slot = models.CharField(max_length=100, blank=True, default="")
    manufacturer = models.CharField(max_length=255, blank=True, default="")
    model = models.CharField(max_length=255, blank=True, default="")
    erp_asset_no = models.CharField(max_length=100, blank=True, default="")
    erp_serial = models.CharField(max_length=255, blank=True, default="")
    observed_serial = models.CharField(max_length=255, blank=True, default="")
    match_status = models.CharField(
        max_length=20,
        choices=MATCH_CHOICES,
        default="unknown",
    )
    source_id = models.CharField(max_length=255, blank=True, default="")
    raw_data = models.JSONField(default=dict, blank=True)
    last_sync = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["erp_asset", "component_type", "slot", "id"]

    def __str__(self):
        return f"{self.erp_asset.asset_no}: {self.component_type} {self.erp_serial}"


class MaintenanceEvent(models.Model):
    erp_asset = models.ForeignKey(
        ERPAsset,
        on_delete=models.CASCADE,
        related_name="maintenance_events",
    )
    external_id = models.CharField(max_length=255)
    event_type = models.CharField(max_length=100, blank=True, default="maintenance")
    opened_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    problem = models.TextField(blank=True, default="")
    action = models.TextField(blank=True, default="")
    vendor = models.CharField(max_length=255, blank=True, default="")
    technician = models.CharField(max_length=255, blank=True, default="")
    old_serial = models.CharField(max_length=255, blank=True, default="")
    new_serial = models.CharField(max_length=255, blank=True, default="")
    component_asset_no = models.CharField(max_length=100, blank=True, default="")
    status = models.CharField(max_length=100, blank=True, default="")
    raw_data = models.JSONField(default=dict, blank=True)
    last_sync = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-opened_at", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["erp_asset", "external_id"],
                name="unique_erpassets_maintenance_external_id",
            )
        ]

    def __str__(self):
        return f"{self.erp_asset.asset_no}: {self.external_id}"
