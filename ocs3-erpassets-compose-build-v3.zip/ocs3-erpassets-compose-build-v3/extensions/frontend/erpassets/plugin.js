// Reference-style OCS3 frontend extension entry point.
window.OCS_EXTENSIONS = window.OCS_EXTENSIONS || {}

window.OCS_EXTENSIONS["erpassets"] = {
    async register(api) {
        const en = await fetch("/extensions/erpassets/locales/en.json").then((r) => r.json())
        api.mergeI18n("en", en)

        // OCS3 RC2 currently ships en/fr only. Keep the Traditional Chinese
        // bundle ready for deployments that expose a zh-TW locale.
        const zhTW = await fetch("/extensions/erpassets/locales/zh_TW.json").then((r) => r.json())
        api.mergeI18n("zh-TW", zhTW)

        const PageMod = await api.importModule(
            "/extensions/erpassets/components/ERPAssetsPage.js",
        )
        const AppLayout = api.getComponent("AppLayout")

        api.addRoute({
            path: "/inventory/erpassets",
            name: "ERPAssets",
            component: PageMod.createComponent(api),
            meta: { layout: AppLayout, requireAuth: true },
        })

        // Match the Proxmox extension style: add ERP Assets inside Inventory.
        api.addMenuChildItem("inventory", {
            headerKey: "erpassets.menu_title",
            link: "/inventory/erpassets",
            route: "ERPAssets",
            column: "general",
        })

        // Match the sample extension style: inject an asset-specific widget.
        api.registerSlot("inventory.asset.detail.afterAccountInfo", {
            component: async () => {
                const mod = await api.importModule(
                    "/extensions/erpassets/components/ERPAssetSlot.js",
                )
                return mod.createComponent(api)
            },
        })
    },
}
