// Asset-detail widget patterned after the official SampleCommentSlot.
export function createComponent(api) {
    const Datatable = api.getComponent("Datatable")
    const Alert = api.getComponent("Alert")
    const Loader = api.getComponent("Loader")

    return {
        name: "ERPAssetSlot",
        components: { Datatable, Alert, Loader },
        props: { assetId: { type: [String, Number], default: null } },

        data() {
            return {
                loading: false,
                record: null,
                error: null,
                componentHeaders: [
                    "component_type",
                    "slot",
                    "erp_asset_no",
                    "erp_serial",
                    "observed_serial",
                    "match_status",
                ],
                maintenanceHeaders: [
                    "external_id",
                    "opened_at",
                    "event_type",
                    "problem",
                    "action",
                    "status",
                ],
            }
        },

        computed: {
            canView() {
                return api.hasPermissions(["erpassets_view_erpasset"])
            },
        },

        watch: {
            assetId: { immediate: true, handler: "load" },
        },

        methods: {
            async load() {
                if (!this.assetId || !this.canView) return

                this.loading = true
                this.error = null
                this.record = null

                try {
                    const { data } = await api.http.get(
                        "/erpassets/assets/by-asset/",
                        { params: { asset_id: this.assetId } },
                    )
                    this.record = data
                } catch (e) {
                    if (e?.response?.status !== 404) {
                        this.error = e?.response?.data?.error || e?.message || String(e)
                    }
                } finally {
                    this.loading = false
                }
            },
        },

        template: `
            <div class="mt-3" v-if="canView">
                <div align="center">
                    <h2>{{ $t('erpassets.title') }}</h2>
                </div>

                <div v-if="loading" class="ocs-loader">
                    <Loader />
                </div>

                <Alert v-if="error" :message="error" variant="danger" />

                <div v-if="!loading && !record" class="alert alert-secondary">
                    {{ $t('erpassets.no_record') }}
                </div>

                <template v-if="record">
                    <div class="datagrid mb-4">
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.asset_no') }}</div>
                            <div class="datagrid-content">{{ record.asset_no }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.erp_serial') }}</div>
                            <div class="datagrid-content">{{ record.erp_serial }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.reconciliation_status') }}</div>
                            <div class="datagrid-content">
                                <span v-if="record.reconciliation_status === 'matched'" class="badge bg-success">MATCHED</span>
                                <span v-else-if="record.reconciliation_status === 'mismatch'" class="badge bg-danger">MISMATCH</span>
                                <span v-else class="badge bg-secondary">UNKNOWN</span>
                            </div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.department') }}</div>
                            <div class="datagrid-content">{{ record.department }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.custodian') }}</div>
                            <div class="datagrid-content">{{ record.custodian }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.location') }}</div>
                            <div class="datagrid-content">{{ record.location }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t('erpassets.status') }}</div>
                            <div class="datagrid-content">{{ record.status }}</div>
                        </div>
                    </div>

                    <h3>{{ $t('erpassets.components') }}</h3>
                    <Datatable
                        :rowdata="record.components || []"
                        :rowheader="componentHeaders"
                        title="erpassets/components"
                        translationkey="erpassets."
                        :candelete="false"
                        :candeletemultiple="false"
                        :usecheckbox="false"
                        @reload-datatable="load"
                    />

                    <h3 class="mt-4">{{ $t('erpassets.maintenance') }}</h3>
                    <Datatable
                        :rowdata="record.maintenance_events || []"
                        :rowheader="maintenanceHeaders"
                        title="erpassets/maintenance"
                        translationkey="erpassets."
                        :candelete="false"
                        :candeletemultiple="false"
                        :usecheckbox="false"
                        @reload-datatable="load"
                    />
                </template>
            </div>
        `,
    }
}
