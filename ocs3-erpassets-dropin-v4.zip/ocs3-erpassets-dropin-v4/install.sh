#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
TARGET="${1:-$PWD}"
DRY_RUN=0
BACKUP=1

usage() {
  cat <<'USAGE'
Usage:
  ./install.sh [TARGET_DIR] [--dry-run] [--no-backup]

Examples:
  ./install.sh ~/audit_your_device/ocsinventory-server-3
  ./install.sh . --dry-run

What it manages:
  docker-compose.yml
  .dockerignore
  docker/backend/Dockerfile
  docker/backend/start-erpassets.sh
  docker/frontend/Dockerfile
  extensions/backend/erpassets/
  extensions/frontend/erpassets/

Other extension directories and unrelated project files are left untouched.
USAGE
}

# Parse optional flags after/without target.
ARGS=()
for arg in "$@"; do
  case "$arg" in
    --dry-run) DRY_RUN=1 ;;
    --no-backup) BACKUP=0 ;;
    -h|--help) usage; exit 0 ;;
    *) ARGS+=("$arg") ;;
  esac
done
if ((${#ARGS[@]} > 0)); then
  TARGET="${ARGS[0]}"
fi
if ((${#ARGS[@]} > 1)); then
  echo "ERROR: too many positional arguments" >&2
  usage >&2
  exit 2
fi

TARGET="$(realpath -m "$TARGET")"

if [[ ! -d "$PAYLOAD" ]]; then
  echo "ERROR: payload directory not found: $PAYLOAD" >&2
  exit 1
fi

if [[ ! -d "$TARGET" ]]; then
  echo "ERROR: target directory does not exist: $TARGET" >&2
  exit 1
fi

if [[ ! -f "$TARGET/docker-compose.yml" ]]; then
  echo "ERROR: target does not look like the OCS3 project (docker-compose.yml missing):" >&2
  echo "       $TARGET" >&2
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$TARGET/.erpassets-backup/$STAMP"

run() {
  if ((DRY_RUN)); then
    printf '[dry-run]'
    printf ' %q' "$@"
    printf '\n'
  else
    "$@"
  fi
}

backup_one() {
  local rel="$1"
  local src="$TARGET/$rel"
  local dst="$BACKUP_DIR/$rel"
  [[ -e "$src" || -L "$src" ]] || return 0
  run mkdir -p "$(dirname "$dst")"
  run cp -a "$src" "$dst"
}

install_file() {
  local rel="$1"
  local src="$PAYLOAD/$rel"
  local dst="$TARGET/$rel"
  [[ -f "$src" ]] || { echo "ERROR: payload file missing: $rel" >&2; exit 1; }
  run mkdir -p "$(dirname "$dst")"
  run cp -a "$src" "$dst"
}

install_clean_dir() {
  local rel="$1"
  local src="$PAYLOAD/$rel"
  local dst="$TARGET/$rel"
  [[ -d "$src" ]] || { echo "ERROR: payload directory missing: $rel" >&2; exit 1; }
  run rm -rf "$dst"
  run mkdir -p "$(dirname "$dst")"
  run cp -a "$src" "$dst"
}

MANAGED=(
  "docker-compose.yml"
  ".dockerignore"
  "docker/backend/Dockerfile"
  "docker/backend/start-erpassets.sh"
  "docker/frontend/Dockerfile"
  "extensions/backend/erpassets"
  "extensions/frontend/erpassets"
)

echo "OCS3 ERP Assets installer"
echo "Source : $PAYLOAD"
echo "Target : $TARGET"

if ((BACKUP)); then
  echo "Backup : $BACKUP_DIR"
  for rel in "${MANAGED[@]}"; do
    backup_one "$rel"
  done
else
  echo "Backup : disabled"
fi

# Replace only files/directories owned by this package.
install_file "docker-compose.yml"
install_file ".dockerignore"
install_file "docker/backend/Dockerfile"
install_file "docker/backend/start-erpassets.sh"
install_file "docker/frontend/Dockerfile"
install_clean_dir "extensions/backend/erpassets"
install_clean_dir "extensions/frontend/erpassets"

run chmod 755 "$TARGET/docker/backend/start-erpassets.sh"

echo
if ((DRY_RUN)); then
  echo "Dry-run finished; no files were changed."
else
  echo "Install finished."
  echo
  echo "Next commands:"
  echo "  cd '$TARGET'"
  echo "  sudo docker compose config"
  echo "  sudo docker compose build --no-cache ocsinventory-backend ocsinventory-frontend"
  echo "  sudo docker compose up -d"
fi
