OCS3 ERP Assets drop-in installer

1. Extract this archive.
2. Run:

   ./install.sh ~/audit_your_device/ocsinventory-server-3

The installer backs up only the files it manages under:

   <target>/.erpassets-backup/<timestamp>/

Other extensions are not removed.

Preview without changing files:

   ./install.sh ~/audit_your_device/ocsinventory-server-3 --dry-run
