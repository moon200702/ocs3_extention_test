# Facility Monitor setup notes

This add-on keeps the existing ERP Assets extension and adds a second OCS3
extension named `facilitymonitor`.

## Runtime flow

```text
OCS web page
  -> [立即取得讀值]
  -> POST /facilitymonitor/readings/capture/
  -> backend calls Camera API
  -> original image is saved + SHA-256 recorded
  -> OpenCV recognizer runs
  -> DB row is created
       success: status=pending
       failure: status=recognition_failed
  -> operator opens the source photo
  -> approve automatic values OR type temperature/humidity manually
  -> reviewed row becomes the official value for that device/date
```

The original OpenCV values are never overwritten by manual review.

## 1. Fill in the Camera API

The safest place is the target OCS3 project's `.env` file.
Use `facility-monitor.env.example` as the template.

At minimum:

```env
FACILITY_CAMERA_URL=http://CAMERA-IP/path/to/snapshot.jpg
FACILITY_CAMERA_AUTH_MODE=none
```

If your endpoint uses Basic auth:

```env
FACILITY_CAMERA_AUTH_MODE=basic
FACILITY_CAMERA_USERNAME=...
FACILITY_CAMERA_PASSWORD=...
```

If it uses Bearer token:

```env
FACILITY_CAMERA_AUTH_MODE=bearer
FACILITY_CAMERA_TOKEN=...
```

Vendor-specific camera request logic lives only in:

```text
extensions/backend/facilitymonitor/services/camera.py
```

Search for `CAMERA API CUSTOMIZATION POINT` in that file.

## 2. Configure the OpenCV recognition profile

Edit:

```text
extensions/backend/facilitymonitor/profiles/profile.json
```

The shipped file has `"enabled": false` deliberately, so an unconfigured ROI
cannot silently create a wrong official reading.

Two modes exist:

- `auto_v3`: current connected-component research recognizer.
- `fixed_segments`: calibrated A..G segment rectangles; preferred for a fixed
  camera/device after the segment boxes have been manually tuned.

A fixed-segment schema example is in:

```text
profiles/profile.fixed-segments.example.json
```

After editing profile.json, set:

```json
"enabled": true
```

## 3. Recognition failure workflow

Recognition failure is NOT fatal to the daily log.
The extension preserves the source image and creates a row with:

```text
status = recognition_failed
```

In OCS -> Inventory -> 機房環境日誌:

1. Click `檢閱`.
2. Inspect the original camera image.
3. Type both temperature and humidity into `人工輸入／更正`.
4. Click `儲存人工數值`.

The row becomes `corrected` and is marked as the official reading for that day.

## 4. Build / install

```bash
./install.sh ~/audit_your_device/ocsinventory-server-3

cd ~/audit_your_device/ocsinventory-server-3
sudo docker compose config
sudo docker compose build --no-cache ocsinventory-backend ocsinventory-frontend
sudo docker compose up -d
```

The backend image installs `opencv-python-headless`, NumPy, and Requests.
The evidence images are stored in the named Docker volume:

```text
ocsinventory-facility-evidence
```

## 5. Permissions

The OCS user needs the generated model permissions for `FacilityReading`:

```text
facilitymonitor_view_facilityreading
facilitymonitor_add_facilityreading
facilitymonitor_change_facilityreading
```

- view: see the page and source image
- add: press Capture now
- change: approve/correct a reading

## Audit notes

Each DB record keeps:

- original image SHA-256
- original automatic temperature/humidity
- approved temperature/humidity separately
- recognizer version
- profile version
- optional deployed Git commit
- recognition evidence JSON
- trigger user/time
- reviewer/time

See `extensions/backend/facilitymonitor/SOURCES.md` for the boundary between
source-backed OpenCV primitives and local engineering heuristics.
