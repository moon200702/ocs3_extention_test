# v7 validation record

The package was checked before archiving with the following tests.

## Static checks

- Python `compileall` passed for both backend extensions.
- `bash -n` passed for the installer and backend start script.
- Every JSON file in the package parsed successfully.
- `node --check` passed for the new Facility Monitor frontend files.

## Recognizer functional test: fixed_segments

A synthetic camera image was generated with:

- temperature digits: `234` with `decimal_places=1` -> `23.4`
- humidity digits: `56` -> `56`

Each digit was drawn from explicit A..G rectangles, then read through the actual
`facilitymonitor.services.recognizer` module.

Observed result:

```text
temperature = 23.4
humidity    = 56
```

The evidence output also contained the expected A..G bit pattern and foreground
ratio for every digit.

## Recognizer regression: auto_v3

The prior raw test frame `vlcsnap-2026-09-23-14h26m01s972.png` was run with:

```text
display_roi     = [620,350,440,210]
expected_digits = 4
```

Observed seven-segment text:

```text
0256
```

Otsu threshold measured by the program:

```text
120
```

## Not yet validated

This environment does not contain the user's real camera endpoint or running
OCS3 stack, so the following still require deployment testing:

- vendor-specific Camera API authentication/response format
- OCS3 permission assignment in the actual instance
- end-to-end extension loader / migration / browser UI in the running RC2 stack
- real temperature/humidity display ROIs and calibrated segment boxes

The shipped recognition profile therefore remains disabled by default to avoid
silently accepting an uncalibrated result.
