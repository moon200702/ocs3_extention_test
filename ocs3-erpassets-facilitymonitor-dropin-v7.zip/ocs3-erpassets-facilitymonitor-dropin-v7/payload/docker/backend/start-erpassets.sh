#!/bin/bash
set -Eeuo pipefail

APP_DIR=/app/ocsinventory-backend
PYTHON=/app/ocs-venv/bin/python
UWSGI=/app/ocs-venv/bin/uwsgi

cd "$APP_DIR"

echo "[extensions] syncing extension manifests"
"$PYTHON" manage.py shell -c '
from extension.sync import sync_extensions_from_filesystem
sync_extensions_from_filesystem()
'

echo "[extensions] enabling ERP Assets + Facility Monitor"
"$PYTHON" manage.py shell -c '
from extension.models import Extension
for app in ("erpassets", "facilitymonitor"):
    obj = Extension.objects.get(django_app=app)
    if not obj.enabled:
        obj.enabled = True
        obj.save(update_fields=["enabled"])
        print(f"[extensions] enabled {app}")
    else:
        print(f"[extensions] already enabled {app}")
'

# The upstream entrypoint already runs migrations, but an extension can be
# newly introduced after that discovery step.  Explicitly running these app
# migrations is idempotent and makes a first install easier to reason about.
echo "[extensions] ensuring extension migrations are applied"
"$PYTHON" manage.py migrate erpassets --noinput
"$PYTHON" manage.py migrate facilitymonitor --noinput

if [[ "${ERP_SYNC_ON_START_ENV:-True}" == "True" ]]; then
    echo "[erpassets] syncing ERP data"
    if ! "$PYTHON" manage.py erp_sync; then
        echo "[erpassets] WARNING: ERP sync failed; continuing OCS backend startup" >&2
    fi
else
    echo "[erpassets] ERP sync on start disabled"
fi

# Facility Monitor is intentionally NOT scheduled here.
# In v7 it is triggered from the OCS web button:
#   POST /facilitymonitor/readings/capture/
# This prevents a hidden background thread or duplicate scheduler from starting
# every time a uWSGI worker/container restarts.

echo "[extensions] starting uWSGI"
exec "$UWSGI" --ini /app/uwsgi.ini
