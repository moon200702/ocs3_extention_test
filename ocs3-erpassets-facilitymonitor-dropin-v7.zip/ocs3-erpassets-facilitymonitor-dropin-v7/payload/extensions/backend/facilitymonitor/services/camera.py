"""Camera snapshot adapter.

THIS IS THE MAIN FILE TO EDIT FOR A VENDOR-SPECIFIC CAMERA API.

The default implementation assumes the configured URL returns JPEG/PNG bytes
from a HTTP GET request.  That is common for snapshot endpoints.

If your camera requires a vendor login handshake, POST body, cookies, or a JSON
response that contains another image URL, keep that special logic in
`fetch_snapshot()` below.  The rest of the Facility Monitor extension should
not need to know how the camera works.
"""

from dataclasses import dataclass
from typing import Dict

import requests
from requests.auth import HTTPBasicAuth

from ..config import camera_config


class CameraError(RuntimeError):
    pass


@dataclass
class Snapshot:
    content: bytes
    content_type: str


def fetch_snapshot() -> Snapshot:
    cfg = camera_config()

    # ---------------------------------------------------------------------
    # CAMERA API CONFIGURATION POINT #1
    # ---------------------------------------------------------------------
    # Put the real snapshot endpoint in the OCS project's `.env` file:
    #
    #   FACILITY_CAMERA_URL=http://192.0.2.50/api/snapshot.jpg
    #
    # Do NOT paste passwords/tokens into this Python source.
    # ---------------------------------------------------------------------
    if not cfg["url"]:
        raise CameraError(
            "FACILITY_CAMERA_URL is empty. Configure the camera snapshot API first."
        )

    headers: Dict[str, str] = dict(cfg.get("extra_headers") or {})
    auth = None

    # ---------------------------------------------------------------------
    # CAMERA API CONFIGURATION POINT #2 - authentication
    # ---------------------------------------------------------------------
    # none:
    #   FACILITY_CAMERA_AUTH_MODE=none
    #
    # basic:
    #   FACILITY_CAMERA_AUTH_MODE=basic
    #   FACILITY_CAMERA_USERNAME=...
    #   FACILITY_CAMERA_PASSWORD=...
    #
    # bearer:
    #   FACILITY_CAMERA_AUTH_MODE=bearer
    #   FACILITY_CAMERA_TOKEN=...
    # ---------------------------------------------------------------------
    mode = cfg["auth_mode"]
    if mode == "basic":
        auth = HTTPBasicAuth(cfg["username"], cfg["password"])
    elif mode == "bearer":
        if not cfg["token"]:
            raise CameraError("Bearer auth selected but FACILITY_CAMERA_TOKEN is empty")
        headers["Authorization"] = f"Bearer {cfg['token']}"
    elif mode != "none":
        raise CameraError(f"Unsupported FACILITY_CAMERA_AUTH_MODE: {mode}")

    # ---------------------------------------------------------------------
    # CAMERA API CUSTOMIZATION POINT #3
    # ---------------------------------------------------------------------
    # DEFAULT: direct image bytes from GET.
    #
    # If your vendor returns JSON first, replace ONLY this block, for example:
    #
    #   meta = requests.get(...).json()
    #   image_url = meta["snapshot_url"]
    #   response = requests.get(image_url, ...)
    #
    # The function must finally return Snapshot(content=<bytes>, content_type=...).
    # ---------------------------------------------------------------------
    try:
        response = requests.get(
            cfg["url"],
            headers=headers,
            auth=auth,
            timeout=cfg["timeout_seconds"],
            verify=cfg["verify_tls"],
        )
        response.raise_for_status()
    except requests.RequestException as exc:
        raise CameraError(f"Camera API request failed: {exc}") from exc

    if not response.content:
        raise CameraError("Camera API returned an empty response")

    content_type = response.headers.get("Content-Type", "image/jpeg").split(";", 1)[0]

    # A HTML login page is a camera transport/authentication failure, not an OCR
    # failure.  application/octet-stream is tolerated because some camera
    # vendors use it for valid JPEG snapshot bytes.
    if not (content_type.startswith("image/") or content_type == "application/octet-stream"):
        raise CameraError(
            f"Camera API returned unexpected Content-Type: {content_type}"
        )

    return Snapshot(content=response.content, content_type=content_type)
