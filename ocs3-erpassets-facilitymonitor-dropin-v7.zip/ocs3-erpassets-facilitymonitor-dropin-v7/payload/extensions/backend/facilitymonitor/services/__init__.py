"""Service layer for camera capture and recognition."""
