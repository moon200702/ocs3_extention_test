"""Traceable seven-segment recognition service.

Two recognition modes are supported per field in profile.json:

1. auto_v3
   Uses thresholding + connected components + geometry clustering.  It keeps the
   special B+C recovery rule for digit `1` from the previous lab prototype.

2. fixed_segments
   Preferred for a fixed CCTV/device after calibration.  Every A..G sampling
   rectangle is explicitly stored in the profile and runtime only measures
   brightness/foreground ratio.  This is more deterministic and easier to audit.

The extension intentionally returns detailed evidence instead of only a number.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from ..config import git_commit, profile_path


RECOGNIZER_VERSION = "facility-sevenseg-0.1.0"

DIGIT_MAP = {
    (1, 1, 1, 1, 1, 1, 0): "0",
    (0, 1, 1, 0, 0, 0, 0): "1",
    (1, 1, 0, 1, 1, 0, 1): "2",
    (1, 1, 1, 1, 0, 0, 1): "3",
    (0, 1, 1, 0, 0, 1, 1): "4",
    (1, 0, 1, 1, 0, 1, 1): "5",
    (1, 0, 1, 1, 1, 1, 1): "6",
    (1, 1, 1, 0, 0, 0, 0): "7",
    (1, 1, 1, 1, 1, 1, 1): "8",
    (1, 1, 1, 1, 0, 1, 1): "9",
}


class RecognitionError(RuntimeError):
    pass


@dataclass
class Component:
    id: int
    x: int
    y: int
    w: int
    h: int
    area: int
    cx: float
    cy: float

    @property
    def aspect(self) -> float:
        return self.w / self.h if self.h else 999.0


@dataclass
class DigitSlot:
    cx: float
    source: str
    evidence: List[int]


def load_profile() -> Dict:
    path = profile_path()
    if not path.exists():
        raise RecognitionError(f"Recognizer profile does not exist: {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if not data.get("enabled", False):
        raise RecognitionError(
            "Recognizer profile is disabled. Edit profiles/profile.json before using auto recognition."
        )
    return data


def decode_image_bytes(image_bytes: bytes) -> np.ndarray:
    buf = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if image is None:
        raise RecognitionError("OpenCV could not decode the camera response as an image")
    return image


def _crop(image: np.ndarray, roi: List[int]) -> np.ndarray:
    if not isinstance(roi, list) or len(roi) != 4:
        raise RecognitionError(f"ROI must be [x,y,w,h], got {roi!r}")
    x, y, w, h = map(int, roi)
    ih, iw = image.shape[:2]
    if min(x, y) < 0 or w <= 0 or h <= 0 or x + w > iw or y + h > ih:
        raise RecognitionError(f"ROI {roi} is invalid for image size {iw}x{ih}")
    return image[y : y + h, x : x + w].copy()


def _digits_to_decimal(text: str, decimal_places: int) -> Decimal:
    if not text or "?" in text:
        raise RecognitionError(f"Cannot convert incomplete digits to a value: {text!r}")
    integer = int(text)
    scale = Decimal(10) ** int(decimal_places)
    return Decimal(integer) / scale


# ---------------------------------------------------------------------------
# fixed_segments mode
# ---------------------------------------------------------------------------

def _recognize_fixed_segments(display: np.ndarray, cfg: Dict) -> Dict:
    gray = cv2.cvtColor(display, cv2.COLOR_BGR2GRAY)
    pixel_threshold = int(cfg.get("pixel_threshold", 150))
    on_ratio = float(cfg.get("on_ratio", 0.35))
    digits_cfg = cfg.get("digits") or []
    if not digits_cfg:
        raise RecognitionError("fixed_segments mode requires a non-empty digits list")

    chars = []
    digit_evidence = []

    for index, digit_cfg in enumerate(digits_cfg):
        segments_cfg = digit_cfg.get("segments") or {}
        bits = []
        ratios = {}

        for name in "ABCDEFG":
            if name not in segments_cfg:
                raise RecognitionError(
                    f"digit {index + 1} is missing segment ROI {name}"
                )
            seg = _crop(gray, segments_cfg[name])
            ratio = float(np.mean(seg >= pixel_threshold))
            ratios[name] = ratio
            bits.append(1 if ratio >= on_ratio else 0)

        bit_tuple = tuple(bits)
        char = DIGIT_MAP.get(bit_tuple, "?")
        chars.append(char)
        digit_evidence.append(
            {
                "digit_index": index,
                "bits_A_to_G": bits,
                "foreground_ratio": ratios,
                "decoded": char,
            }
        )

    text = "".join(chars)
    if "?" in text:
        raise RecognitionError(f"fixed_segments produced an unknown pattern: {text}")

    return {
        "text": text,
        "method": "fixed_segments",
        "pixel_threshold": pixel_threshold,
        "on_ratio": on_ratio,
        "digits": digit_evidence,
    }


# ---------------------------------------------------------------------------
# auto_v3 mode - current research prototype, kept separate from Django code.
# ---------------------------------------------------------------------------

def _cluster_1d(values: List[float], tolerance: float) -> List[List[float]]:
    values = sorted(values)
    clusters: List[List[float]] = []
    for value in values:
        if not clusters:
            clusters.append([value])
            continue
        med = float(np.median(clusters[-1]))
        if abs(value - med) <= tolerance:
            clusters[-1].append(value)
        else:
            clusters.append([value])
    return clusters


def _components(binary: np.ndarray) -> List[Component]:
    count, _, stats, centroids = cv2.connectedComponentsWithStats(binary, 8)
    out = []
    for i in range(1, count):
        x, y, w, h, area = map(int, stats[i])
        cx, cy = map(float, centroids[i])
        out.append(Component(i, x, y, w, h, area, cx, cy))
    return out


def _recognize_auto_v3(display: np.ndarray, cfg: Dict) -> Dict:
    expected_digits = int(cfg.get("expected_digits", 4))
    aspect_threshold = float(cfg.get("aspect_threshold", 3.0))
    min_area_ratio = float(cfg.get("min_area_ratio", 0.0012))

    gray = cv2.cvtColor(display, cv2.COLOR_BGR2GRAY)
    threshold_value, binary = cv2.threshold(
        gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    comps = _components(binary)
    min_area = max(20, int(round(display.shape[0] * display.shape[1] * min_area_ratio)))

    horizontal0 = [
        c for c in comps if c.area >= min_area and c.aspect >= aspect_threshold
    ]
    vertical0 = [
        c for c in comps
        if c.area >= min_area and (1.0 / c.aspect) >= aspect_threshold
    ]
    if not horizontal0 or not vertical0:
        raise RecognitionError("auto_v3 could not find both horizontal and vertical segments")

    median_h_width = float(np.median([c.w for c in horizontal0]))
    median_v_height = float(np.median([c.h for c in vertical0]))
    horizontal = [
        c for c in horizontal0
        if 0.70 * median_h_width <= c.w <= 1.30 * median_h_width
    ]
    vertical = [
        c for c in vertical0
        if 0.70 * median_v_height <= c.h <= 1.30 * median_v_height
    ]
    if not horizontal or not vertical:
        raise RecognitionError("auto_v3 geometry filtering removed all segment candidates")

    x_tolerance = median_h_width * 0.30
    x_clusters = [
        c for c in _cluster_1d([x.cx for x in horizontal], x_tolerance)
        if len(c) >= 2
    ]
    ordinary_slots = [
        DigitSlot(float(np.median(c)), "horizontal_cluster", []) for c in x_clusters
    ]

    median_h_height = float(np.median([c.h for c in horizontal]))
    y_clusters = _cluster_1d([c.cy for c in horizontal], median_h_height * 2.0)
    if len(y_clusters) != 3:
        raise RecognitionError(
            f"auto_v3 expected three horizontal rows A/G/D, found {len(y_clusters)}"
        )
    top_y, middle_y, bottom_y = [float(np.median(c)) for c in y_clusters]

    # Estimate the right-side B/C offset from ordinary digits in this frame.
    offsets = []
    for slot in ordinary_slots:
        for c in vertical:
            dx = c.cx - slot.cx
            if 0.10 * median_h_width <= dx <= 0.90 * median_h_width:
                if top_y < c.cy < bottom_y:
                    offsets.append(dx)
    right_offset = float(np.median(offsets)) if offsets else None

    # Explicit digit-1 recovery: a standalone upper-right + lower-right pair.
    recovered = []
    if right_offset is not None:
        upper = [c for c in vertical if top_y < c.cy < middle_y]
        lower = [c for c in vertical if middle_y < c.cy < bottom_y]
        pair_tol = max(2.0, 0.25 * float(np.median([c.w for c in vertical])))
        for up in upper:
            for low in lower:
                if abs(up.cx - low.cx) > pair_tol:
                    continue
                pair_x = (up.cx + low.cx) / 2.0
                inferred = pair_x - right_offset
                # A normal digit can also contain B+C; do not manufacture a 1
                # inside an already-established digit neighbourhood.
                if any(
                    abs(pair_x - s.cx) <= 0.90 * median_h_width
                    for s in ordinary_slots
                ):
                    continue
                if any(abs(inferred - s.cx) <= 0.30 * median_h_width for s in recovered):
                    continue
                recovered.append(
                    DigitSlot(inferred, "digit_1_vertical_pair", [up.id, low.id])
                )

    slots = sorted(ordinary_slots + recovered, key=lambda s: s.cx)
    if len(slots) != expected_digits:
        # Fail visibly instead of silently returning fewer digits.  The web UI
        # will preserve the photo and offer manual temperature/humidity entry.
        raise RecognitionError(
            f"auto_v3 found {len(slots)} digit slots, expected {expected_digits}"
        )

    decoded = []
    chars = []
    for slot_index, slot in enumerate(slots):
        seg = {name: 0 for name in "ABCDEFG"}
        evidence = {name: [] for name in "ABCDEFG"}

        for c in horizontal:
            if abs(c.cx - slot.cx) > x_tolerance:
                continue
            row_index = int(np.argmin([
                abs(c.cy - top_y),
                abs(c.cy - middle_y),
                abs(c.cy - bottom_y),
            ]))
            name = ("A", "G", "D")[row_index]
            seg[name] = 1
            evidence[name].append(c.id)

        for c in vertical:
            nearest = int(np.argmin([abs(c.cx - s.cx) for s in slots]))
            if nearest != slot_index or abs(c.cx - slot.cx) > median_h_width * 0.90:
                continue
            is_left = c.cx < slot.cx
            is_upper = c.cy < middle_y
            if is_upper and is_left:
                name = "F"
            elif is_upper:
                name = "B"
            elif is_left:
                name = "E"
            else:
                name = "C"
            seg[name] = 1
            evidence[name].append(c.id)

        bits = tuple(seg[name] for name in "ABCDEFG")
        char = DIGIT_MAP.get(bits, "?")
        chars.append(char)
        decoded.append(
            {
                "slot": slot_index + 1,
                "centre_x": slot.cx,
                "slot_source": slot.source,
                "slot_evidence": slot.evidence,
                "bits_A_to_G": list(bits),
                "component_evidence": evidence,
                "decoded": char,
            }
        )

    text = "".join(chars)
    if "?" in text:
        raise RecognitionError(f"auto_v3 produced an unknown digit pattern: {text}")

    return {
        "text": text,
        "method": "auto_v3",
        "threshold": float(threshold_value),
        "digit_centres": [s.cx for s in slots],
        "right_vertical_offset": right_offset,
        "digits": decoded,
    }


def recognize(image_bytes: bytes) -> Dict:
    image = decode_image_bytes(image_bytes)
    profile = load_profile()

    fields_result = {}
    values = {}
    overall_ok = True

    for field_name in ("temperature", "humidity"):
        cfg = (profile.get("fields") or {}).get(field_name) or {}
        try:
            display = _crop(image, cfg.get("display_roi"))
            mode = cfg.get("mode", "auto_v3")
            if mode == "fixed_segments":
                evidence = _recognize_fixed_segments(display, cfg)
            elif mode == "auto_v3":
                evidence = _recognize_auto_v3(display, cfg)
            else:
                raise RecognitionError(f"Unsupported recognition mode: {mode}")

            value = _digits_to_decimal(
                evidence["text"],
                int(cfg.get("decimal_places", 0)),
            )
            fields_result[field_name] = {
                "ok": True,
                "value": str(value),
                "unit": cfg.get("unit", ""),
                "evidence": evidence,
            }
            values[field_name] = value
        except Exception as exc:
            overall_ok = False
            fields_result[field_name] = {
                "ok": False,
                "error": str(exc),
            }
            values[field_name] = None

    return {
        "ok": overall_ok,
        "temperature": values["temperature"],
        "humidity": values["humidity"],
        "recognizer_version": RECOGNIZER_VERSION,
        "profile_version": str(profile.get("version", "unknown")),
        "git_commit": git_commit(),
        "fields": fields_result,
        "source_image_sha256": hashlib.sha256(image_bytes).hexdigest(),
    }
