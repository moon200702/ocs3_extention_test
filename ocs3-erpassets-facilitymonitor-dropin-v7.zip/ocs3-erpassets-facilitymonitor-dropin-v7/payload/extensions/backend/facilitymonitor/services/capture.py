"""Orchestrates one web-triggered capture/recognition attempt."""

from __future__ import annotations

import hashlib
import uuid
from pathlib import Path

from django.utils import timezone

from ..config import device_name, evidence_root, git_commit
from ..models import FacilityReading
from .camera import fetch_snapshot
from .recognizer import RECOGNIZER_VERSION, recognize


def _extension_for(content_type: str) -> str:
    content_type = (content_type or "").lower()
    if "png" in content_type:
        return ".png"
    if "webp" in content_type:
        return ".webp"
    return ".jpg"


def capture_and_recognize(user) -> FacilityReading:
    snapshot = fetch_snapshot()
    now = timezone.now()
    root = evidence_root()
    day_dir = root / now.strftime("%Y/%m/%d")
    day_dir.mkdir(parents=True, exist_ok=True)

    digest = hashlib.sha256(snapshot.content).hexdigest()
    filename = (
        f"{now.strftime('%Y%m%dT%H%M%S')}_"
        f"{uuid.uuid4().hex[:8]}{_extension_for(snapshot.content_type)}"
    )
    path = day_dir / filename

    # Atomic-ish write within the same directory: write .tmp then rename.
    tmp_path = path.with_suffix(path.suffix + ".tmp")
    tmp_path.write_bytes(snapshot.content)
    tmp_path.replace(path)

    relative_path = str(path.relative_to(root))

    try:
        result = recognize(snapshot.content)
        status = "pending" if result["ok"] else "recognition_failed"
        errors = [
            f"{name}: {item.get('error')}"
            for name, item in result["fields"].items()
            if not item.get("ok")
        ]
        reading = FacilityReading.objects.create(
            device_name=device_name(),
            log_date=timezone.localdate(),
            captured_at=now,
            source_image_path=relative_path,
            source_image_sha256=digest,
            source_content_type=snapshot.content_type,
            recognized_temperature=result["temperature"],
            recognized_humidity=result["humidity"],
            status=status,
            recognition_error="; ".join(errors),
            recognition_evidence=result,
            recognizer_version=result["recognizer_version"],
            profile_version=result["profile_version"],
            git_commit=result["git_commit"],
            triggered_by=user,
        )
    except Exception as exc:
        # Important: recognition failure must NOT discard the source photo.
        # The operator still needs the image to type the values manually.
        reading = FacilityReading.objects.create(
            device_name=device_name(),
            log_date=timezone.localdate(),
            captured_at=now,
            source_image_path=relative_path,
            source_image_sha256=digest,
            source_content_type=snapshot.content_type,
            status="recognition_failed",
            recognition_error=str(exc),
            recognition_evidence={"ok": False, "error": str(exc)},
            recognizer_version=RECOGNIZER_VERSION,
            profile_version="unknown",
            git_commit=git_commit(),
            triggered_by=user,
        )

    return reading
