from pathlib import Path

from django.db import transaction
from django.http import FileResponse
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied

from permission.permissions import DefaultModelPermissions

from .config import evidence_root
from .models import FacilityReading
from .serializer import FacilityReadingSerializer, FacilityReviewSerializer
from .services.capture import capture_and_recognize
from .services.camera import CameraError


class FacilityReadingViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Readings are immutable through normal CRUD.

    New records come only from `capture`; human decisions go through `review`.
    This avoids an ordinary PATCH accidentally overwriting recognition evidence.
    """

    permission_classes = [DefaultModelPermissions]
    serializer_class = FacilityReadingSerializer
    queryset = FacilityReading.objects.select_related(
        "triggered_by", "reviewed_by"
    ).all()
    filter_backends = [OrderingFilter]
    ordering_fields = ["captured_at", "created_at", "log_date", "status"]
    ordering = ["-captured_at"]

    def get_queryset(self):
        qs = super().get_queryset()
        log_date = self.request.query_params.get("log_date")
        status_value = self.request.query_params.get("status")
        if log_date:
            qs = qs.filter(log_date=log_date)
        if status_value:
            qs = qs.filter(status=status_value)
        return qs

    @action(detail=False, methods=["post"], url_path="capture")
    def capture(self, request):
        """
        Web button endpoint.

        Frontend -> POST /facilitymonitor/readings/capture/
        Backend  -> camera API -> OpenCV -> DB -> return reading
        """
        try:
            reading = capture_and_recognize(request.user)
        except CameraError as exc:
            # Camera transport failure is different from recognition failure:
            # without a source image there is nothing for the operator to review.
            return Response(
                {"error": str(exc)},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        return Response(
            FacilityReadingSerializer(reading).data,
            status=status.HTTP_201_CREATED,
        )

    @action(detail=True, methods=["get"], url_path="image")
    def image(self, request, pk=None):
        reading = self.get_object()
        root = evidence_root()
        path = (root / reading.source_image_path).resolve()

        # Prevent path traversal even if the DB path were ever corrupted.
        if root not in path.parents:
            return Response(
                {"error": "Invalid evidence path"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if not path.is_file():
            return Response(
                {"error": "Evidence image is missing"},
                status=status.HTTP_404_NOT_FOUND,
            )

        return FileResponse(
            path.open("rb"),
            content_type=reading.source_content_type or "image/jpeg",
        )

    @action(detail=True, methods=["post"], url_path="review")
    def review(self, request, pk=None):
        """
        Human review endpoint.

        action=approve:
            Accept OpenCV values exactly as recognized.

        action=manual:
            Use operator-entered temperature + humidity.  This is available
            both after a recognition failure and as a correction after a
            successful-but-wrong recognition.
        """
        if not request.user.has_perm("facilitymonitor.change_facilityreading"):
            raise PermissionDenied("change_facilityreading permission is required")

        reading = self.get_object()
        form = FacilityReviewSerializer(data=request.data)
        form.is_valid(raise_exception=True)
        action_name = form.validated_data["action"]

        with transaction.atomic():
            reading = FacilityReading.objects.select_for_update().get(pk=reading.pk)

            if action_name == "approve":
                if (
                    reading.recognized_temperature is None
                    or reading.recognized_humidity is None
                ):
                    return Response(
                        {
                            "error": (
                                "Recognition is incomplete; use manual review "
                                "and enter both values."
                            )
                        },
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                reading.approved_temperature = reading.recognized_temperature
                reading.approved_humidity = reading.recognized_humidity
                reading.status = "approved"
            else:
                reading.approved_temperature = form.validated_data["temperature"]
                reading.approved_humidity = form.validated_data["humidity"]
                reading.status = "corrected"

            # Keep every capture attempt, but mark only the latest reviewed one
            # as the official reading for this device/date.
            FacilityReading.objects.filter(
                device_name=reading.device_name,
                log_date=reading.log_date,
                is_official=True,
            ).exclude(pk=reading.pk).update(is_official=False)

            reading.is_official = True
            reading.reviewed_by = request.user
            reading.reviewed_at = timezone.now()
            reading.save(
                update_fields=[
                    "approved_temperature",
                    "approved_humidity",
                    "status",
                    "is_official",
                    "reviewed_by",
                    "reviewed_at",
                ]
            )

        return Response(FacilityReadingSerializer(reading).data)
