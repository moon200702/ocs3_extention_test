# Facility Monitor recognition provenance

## Source-backed primitives

OpenCV thresholding / Otsu thresholding:
https://docs.opencv.org/4.x/d7/d4d/tutorial_py_thresholding.html

OpenCV connected components and component statistics:
https://docs.opencv.org/4.x/d3/dc0/group__imgproc__shape.html

Related seven-segment research:
Finnegan E, Villarroel M, Velardo C, Tarassenko L. 2019.
https://pubmed.ncbi.nlm.nih.gov/31679409/
https://eng.ox.ac.uk/lcmt/resources/resources-seven-segment

## Local engineering heuristics

`auto_v3` contains project-specific geometry rules, including explicit recovery
of digit `1` from a standalone B+C vertical pair and an exact expected digit
count.  These are NOT claimed as literature-standard constants.

`fixed_segments` is a deployment-oriented calibration strategy: segment ROIs,
pixel threshold, and ON ratio are equipment-profile values and must be validated
for each camera/display installation.
