"""OCS3 Facility Monitor extension."""
