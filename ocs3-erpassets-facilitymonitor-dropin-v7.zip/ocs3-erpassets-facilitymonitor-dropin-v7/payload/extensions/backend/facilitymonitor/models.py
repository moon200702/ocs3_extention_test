from django.conf import settings
from django.db import models


class FacilityReading(models.Model):
    """
    One capture/recognition attempt.

    The original machine result is never overwritten by human review.
    This preserves the audit trail and gives us a future regression dataset.
    """

    STATUS_CHOICES = [
        ("pending", "Pending review"),
        ("recognition_failed", "Recognition failed"),
        ("approved", "Approved"),
        ("corrected", "Corrected / manually entered"),
    ]

    device_name = models.CharField(max_length=255, db_index=True)
    log_date = models.DateField(db_index=True)
    captured_at = models.DateTimeField(db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    # Source evidence.  The actual image stays on the evidence volume; the DB
    # stores a relative path and SHA-256 hash so we can verify provenance later.
    source_image_path = models.CharField(max_length=500)
    source_image_sha256 = models.CharField(max_length=64)
    source_content_type = models.CharField(max_length=100, blank=True, default="image/jpeg")

    # OpenCV output.  Nullable by design: if recognition fails, the image is
    # still saved and the operator can enter the values manually in the UI.
    recognized_temperature = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True
    )
    recognized_humidity = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True
    )

    # Human-approved values.  On a normal approval they are copied from the
    # recognized values.  On a correction/failure they contain manual input.
    approved_temperature = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True
    )
    approved_humidity = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True
    )

    status = models.CharField(
        max_length=32,
        choices=STATUS_CHOICES,
        default="pending",
        db_index=True,
    )
    is_official = models.BooleanField(default=False, db_index=True)
    recognition_error = models.TextField(blank=True, default="")
    recognition_evidence = models.JSONField(default=dict, blank=True)
    recognizer_version = models.CharField(max_length=100, blank=True, default="")
    profile_version = models.CharField(max_length=100, blank=True, default="")
    git_commit = models.CharField(max_length=100, blank=True, default="unknown")

    triggered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="facility_readings_triggered",
    )
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="facility_readings_reviewed",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-captured_at", "-id"]

    def __str__(self):
        return f"{self.device_name} {self.captured_at} ({self.status})"
