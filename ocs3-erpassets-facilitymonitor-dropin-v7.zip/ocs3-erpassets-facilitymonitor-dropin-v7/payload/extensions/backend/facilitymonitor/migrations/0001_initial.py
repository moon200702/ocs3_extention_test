from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="FacilityReading",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("device_name", models.CharField(db_index=True, max_length=255)),
                ("log_date", models.DateField(db_index=True)),
                ("captured_at", models.DateTimeField(db_index=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("source_image_path", models.CharField(max_length=500)),
                ("source_image_sha256", models.CharField(max_length=64)),
                ("source_content_type", models.CharField(blank=True, default="image/jpeg", max_length=100)),
                ("recognized_temperature", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("recognized_humidity", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("approved_temperature", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("approved_humidity", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("status", models.CharField(choices=[("pending", "Pending review"), ("recognition_failed", "Recognition failed"), ("approved", "Approved"), ("corrected", "Corrected / manually entered")], db_index=True, default="pending", max_length=32)),
                ("is_official", models.BooleanField(db_index=True, default=False)),
                ("recognition_error", models.TextField(blank=True, default="")),
                ("recognition_evidence", models.JSONField(blank=True, default=dict)),
                ("recognizer_version", models.CharField(blank=True, default="", max_length=100)),
                ("profile_version", models.CharField(blank=True, default="", max_length=100)),
                ("git_commit", models.CharField(blank=True, default="unknown", max_length=100)),
                ("reviewed_at", models.DateTimeField(blank=True, null=True)),
                ("reviewed_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="facility_readings_reviewed", to=settings.AUTH_USER_MODEL)),
                ("triggered_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="facility_readings_triggered", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-captured_at", "-id"]},
        ),
    ]
