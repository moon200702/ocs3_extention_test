from django.apps import AppConfig


class FacilitymonitorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "extensions.facilitymonitor"
    verbose_name = "Facility Monitor"
