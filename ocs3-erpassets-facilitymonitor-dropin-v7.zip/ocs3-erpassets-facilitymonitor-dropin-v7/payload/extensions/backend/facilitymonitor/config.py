"""
Facility Monitor runtime configuration.

IMPORTANT CAMERA API NOTES
==========================
The camera URL and credentials are intentionally NOT hard-coded here.
Set them in the OCS project's `.env` file (or another Docker secret/env source).
See `facility-monitor.env.example` in the drop-in package.

The minimum setting is:

    FACILITY_CAMERA_URL=https://camera.example.local/api/snapshot

Supported authentication modes:

    none   - no Authorization header
    basic  - HTTP Basic auth; set USERNAME + PASSWORD
    bearer - Authorization: Bearer <token>; set TOKEN

If your camera API does NOT return image bytes directly (for example it first
returns JSON containing another image URL), edit `services/camera.py` at the
clearly marked CAMERA API CUSTOMIZATION section.  Keeping vendor-specific code
in that one file avoids mixing it into Django views or OpenCV logic.
"""

import json
import os
from pathlib import Path


def _bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def camera_config():
    return {
        "url": os.getenv("FACILITY_CAMERA_URL", "").strip(),
        "auth_mode": os.getenv("FACILITY_CAMERA_AUTH_MODE", "none").strip().lower(),
        "username": os.getenv("FACILITY_CAMERA_USERNAME", ""),
        "password": os.getenv("FACILITY_CAMERA_PASSWORD", ""),
        "token": os.getenv("FACILITY_CAMERA_TOKEN", ""),
        "timeout_seconds": float(os.getenv("FACILITY_CAMERA_TIMEOUT", "10")),
        "verify_tls": _bool_env("FACILITY_CAMERA_VERIFY_TLS", True),
        # Optional JSON object, e.g. {"X-Vendor-Header":"value"}.
        # Prefer secrets in dedicated env vars instead of putting passwords here.
        "extra_headers": json.loads(os.getenv("FACILITY_CAMERA_HEADERS_JSON", "") or "{}"),
    }


def evidence_root() -> Path:
    # This path is backed by a named Docker volume in docker-compose.yml.
    return Path(
        os.getenv(
            "FACILITY_EVIDENCE_DIR",
            "/var/lib/ocs-facility-monitor",
        )
    ).resolve()


def profile_path() -> Path:
    default = Path(__file__).resolve().parent / "profiles" / "profile.json"
    return Path(os.getenv("FACILITY_RECOGNIZER_PROFILE", str(default))).resolve()


def device_name() -> str:
    return os.getenv("FACILITY_DEVICE_NAME", "server-room-environment").strip()


def git_commit() -> str:
    # Optional but strongly recommended when CI/CD builds the backend image.
    # Pass the deployed commit SHA through this environment variable.
    return os.getenv("FACILITY_RECOGNIZER_GIT_COMMIT", "unknown").strip()
