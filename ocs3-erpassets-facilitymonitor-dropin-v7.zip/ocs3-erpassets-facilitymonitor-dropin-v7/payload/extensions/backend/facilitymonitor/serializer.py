from rest_framework import serializers

from .models import FacilityReading


class FacilityReadingSerializer(serializers.ModelSerializer):
    triggered_by_username = serializers.CharField(
        source="triggered_by.username", read_only=True
    )
    reviewed_by_username = serializers.CharField(
        source="reviewed_by.username", read_only=True
    )

    class Meta:
        model = FacilityReading
        fields = [
            "id",
            "device_name",
            "log_date",
            "captured_at",
            "created_at",
            "source_image_sha256",
            "recognized_temperature",
            "recognized_humidity",
            "approved_temperature",
            "approved_humidity",
            "status",
            "is_official",
            "recognition_error",
            "recognition_evidence",
            "recognizer_version",
            "profile_version",
            "git_commit",
            "triggered_by_username",
            "reviewed_by_username",
            "reviewed_at",
        ]
        read_only_fields = fields


class FacilityReviewSerializer(serializers.Serializer):
    action = serializers.ChoiceField(choices=["approve", "manual"])
    temperature = serializers.DecimalField(
        max_digits=8, decimal_places=2, required=False
    )
    humidity = serializers.DecimalField(
        max_digits=8, decimal_places=2, required=False
    )

    def validate(self, attrs):
        if attrs["action"] == "manual":
            # We deliberately require BOTH values.  This prevents a failed
            # recognition from accidentally becoming an incomplete official log.
            if "temperature" not in attrs or "humidity" not in attrs:
                raise serializers.ValidationError(
                    "temperature and humidity are both required for manual review"
                )
        return attrs
