import os
from urllib.parse import urljoin

import requests
from asset.inventory_base.models import InventoryBase
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from extensions.erpassets.config import load_config
from extensions.erpassets.models import ERPAsset


def _nested_get(data, path, default=""):
    if not path:
        return default
    value = data
    for key in str(path).split("."):
        if not isinstance(value, dict) or key not in value:
            return default
        value = value[key]
    return value


def _normalise_records(payload):
    """Accept both list responses and the ERP envelope used by the demo API.

    Supported examples:
      [{...}, {...}]
      {"results": [...]}
      {"items": [...]}
      {"data": [...]}
      {"status": "success", "code": 200, "data": {...}, "message": "..."}
    """
    if isinstance(payload, list):
        return payload

    if isinstance(payload, dict):
        # If the application-level envelope explicitly reports an error, do
        # not silently consume it just because HTTP itself returned 200.
        app_code = payload.get("code")
        app_status = str(payload.get("status", "")).lower()
        if (isinstance(app_code, int) and app_code >= 400) or app_status in {
            "error",
            "failed",
            "failure",
        }:
            raise CommandError(
                f"ERP API reported failure: code={app_code!r}, "
                f"status={payload.get('status')!r}, message={payload.get('message')!r}"
            )

        for key in ("results", "items"):
            value = payload.get(key)
            if isinstance(value, list):
                return value

        data = payload.get("data")
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return [data]

        # Some ERP endpoints return one asset object directly instead of an
        # envelope, e.g. {"property_number": ..., "ocs_serial": ...}.
        return [payload]

    raise CommandError(
        "ERP response does not contain asset records. Expected a JSON object/list, "
        "results/items list, or a data object/list."
    )


class Command(BaseCommand):
    help = "Pull ERP asset records and link them to OCS assets using ERP-reported OCS serials."

    def add_arguments(self, parser):
        parser.add_argument("--url", help="Override ERP API base URL")
        parser.add_argument("--endpoint", help="Override asset endpoint path")
        parser.add_argument("--limit", type=int, default=0, help="Process only N records")
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Fetch and reconcile without writing ERPAsset rows",
        )

    def handle(self, *args, **options):
        config = load_config()
        base_url = (options.get("url") or config.get("base_url") or "").strip()
        endpoint = options.get("endpoint")
        if endpoint is None:
            endpoint = config.get("assets_endpoint", "")

        if not base_url:
            raise CommandError("ERP API base_url is empty")

        request_url = urljoin(base_url.rstrip("/") + "/", str(endpoint or "").lstrip("/"))
        timeout = int(config.get("timeout_seconds", 10))

        headers = {"Accept": "application/json"}
        token = os.getenv("ERP_API_TOKEN", "").strip()
        if token:
            header = config.get("auth_header", "Authorization")
            scheme = str(config.get("auth_scheme", "Bearer")).strip()
            headers[header] = f"{scheme} {token}".strip()

        self.stdout.write(f"ERP URL: {request_url}")
        try:
            response = requests.get(request_url, headers=headers, timeout=timeout)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise CommandError(f"ERP request failed: {exc}") from exc

        try:
            payload = response.json()
        except ValueError as exc:
            raise CommandError(
                "ERP endpoint did not return JSON. Set assets_endpoint in "
                "extensions/erpassets/config.json to the actual asset API path."
            ) from exc

        records = _normalise_records(payload)
        limit = options.get("limit") or 0
        if limit > 0:
            records = records[:limit]

        mapping = config.get("mapping", {})
        created = updated = unmatched = ambiguous = invalid = 0

        for item in records:
            if not isinstance(item, dict):
                invalid += 1
                continue

            asset_no = str(
                _nested_get(item, mapping.get("asset_no", "property_number"), "") or ""
            ).strip()
            reported_ocs_serial = str(
                _nested_get(item, mapping.get("ocs_serial", "ocs_serial"), "") or ""
            ).strip()
            reported_ocs_asset = str(
                _nested_get(item, mapping.get("reported_ocs_asset", "ocs_asset"), "") or ""
            ).strip()

            if not asset_no or not reported_ocs_serial:
                invalid += 1
                self.stdout.write(
                    self.style.WARNING(
                        f"INVALID property_number={asset_no!r}, ocs_serial={reported_ocs_serial!r}"
                    )
                )
                continue

            # The ERP payload already identifies which OCS serial the property
            # record belongs to. ERP serial is a separate ERP-side identifier.
            candidates = list(
                InventoryBase.objects.filter(serial__iexact=reported_ocs_serial)[:3]
            )
            if not candidates:
                unmatched += 1
                self.stdout.write(
                    self.style.WARNING(
                        f"UNMATCHED {asset_no}: ocs_serial={reported_ocs_serial} "
                        f"ocs_asset={reported_ocs_asset!r}"
                    )
                )
                continue
            if len(candidates) > 1:
                ambiguous += 1
                self.stdout.write(
                    self.style.WARNING(
                        f"AMBIGUOUS {asset_no}: ocs_serial={reported_ocs_serial}, "
                        f"assets={[x.id for x in candidates]}"
                    )
                )
                continue

            asset = candidates[0]
            defaults = {
                "erp_serial": str(
                    _nested_get(item, mapping.get("erp_serial", "erp_serial"), "") or ""
                ).strip(),
                "reported_ocs_asset": reported_ocs_asset,
                "reported_ocs_serial": reported_ocs_serial,
                "reconciliation_status": str(
                    _nested_get(
                        item,
                        mapping.get("reconciliation_status", "reconciliation_status"),
                        "unknown",
                    )
                    or "unknown"
                ).strip(),
                "department": str(
                    _nested_get(item, mapping.get("department", "department"), "") or ""
                ).strip(),
                "custodian": str(
                    _nested_get(item, mapping.get("custodian", "custodian"), "") or ""
                ).strip(),
                "location": str(
                    _nested_get(item, mapping.get("location", "location"), "") or ""
                ).strip(),
                "status": str(
                    _nested_get(item, mapping.get("status", ""), "") or ""
                ).strip(),
                "source_system": "ERP",
                "source_id": str(
                    _nested_get(item, mapping.get("source_id", "property_number"), asset_no)
                    or asset_no
                ).strip(),
                "raw_data": item,
            }

            if options.get("dry_run"):
                exists = ERPAsset.objects.filter(asset_no=asset_no).exists()
                updated += int(exists)
                created += int(not exists)
                self.stdout.write(
                    f"DRY-RUN {'UPDATE' if exists else 'CREATE'} {asset_no} "
                    f"-> OCS asset #{asset.id} ({asset.name}, {asset.serial}) "
                    f"status={defaults['reconciliation_status']}"
                )
                continue

            with transaction.atomic():
                record = ERPAsset.objects.select_for_update().filter(asset_no=asset_no).first()
                is_created = record is None
                if record is None:
                    record = ERPAsset(asset=asset, asset_no=asset_no)
                else:
                    record.asset = asset

                for key, value in defaults.items():
                    setattr(record, key, value)
                record.save()

            created += int(is_created)
            updated += int(not is_created)

        self.stdout.write(
            self.style.SUCCESS(
                "ERP sync complete: "
                f"created={created}, updated={updated}, unmatched={unmatched}, "
                f"ambiguous={ambiguous}, invalid={invalid}"
            )
        )
