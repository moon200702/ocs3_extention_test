window.OCS_EXTENSIONS = window.OCS_EXTENSIONS || {}
console.info("[facilitymonitor] plugin.js loaded")

window.OCS_EXTENSIONS["facilitymonitor"] = {
    async register(api) {
        const en = await fetch("/extensions/facilitymonitor/locales/en.json").then((r) => r.json())
        api.mergeI18n("en", en)

        try {
            const zhTW = await fetch("/extensions/facilitymonitor/locales/zh_TW.json").then((r) => r.json())
            api.mergeI18n("zh-TW", zhTW)
        } catch (e) {
            console.warn("[facilitymonitor] zh-TW locale skipped", e)
        }

        const PageMod = await api.importModule(
            "/extensions/facilitymonitor/components/FacilityMonitorPage.js",
        )
        const AppLayout = api.getComponent("AppLayout")

        api.addRoute({
            path: "/inventory/facility-monitor",
            name: "FacilityMonitor",
            component: PageMod.createComponent(api),
            meta: { layout: AppLayout, requireAuth: true },
        })

        api.addMenuChildItem("inventory", {
            headerKey: "facilitymonitor.menu_title",
            link: "/inventory/facility-monitor",
            route: "FacilityMonitor",
            column: "general",
        })
    },
}
