export function createComponent(api) {
    const PageHeader = api.getComponent("PageHeader")
    const Alert = api.getComponent("Alert")
    const Loader = api.getComponent("Loader")

    return {
        name: "FacilityMonitorPage",
        components: { PageHeader, Alert, Loader },

        data() {
            return {
                readings: [],
                loading: false,
                captureLoading: false,
                errored: false,
                errormsg: null,
                selected: null,
                selectedImageUrl: null,
                manualTemperature: "",
                manualHumidity: "",
                canview: false,
                canadd: false,
                canchange: false,
            }
        },

        methods: {
            checkPermissions() {
                this.canview = api.hasPermissions(["facilitymonitor_view_facilityreading"])
                this.canadd = api.hasPermissions(["facilitymonitor_add_facilityreading"])
                this.canchange = api.hasPermissions(["facilitymonitor_change_facilityreading"])
                if (!this.canview) {
                    this.errored = true
                    this.errormsg = this.$t("facilitymonitor.no_view_permission")
                }
            },

            async load() {
                if (!this.canview) return
                this.loading = true
                this.errored = false
                this.errormsg = null
                try {
                    const response = await api.http.get(
                        "/facilitymonitor/readings/?ordering=-captured_at",
                    )
                    this.readings = response?.data?.results ?? response?.data ?? []
                } catch (e) {
                    this.errormsg = e?.response?.data?.error || e?.message || String(e)
                    this.errored = true
                } finally {
                    this.loading = false
                }
            },

            async captureNow() {
                if (!this.canadd || this.captureLoading) return
                this.captureLoading = true
                this.errored = false
                this.errormsg = null
                try {
                    const response = await api.http.post(
                        "/facilitymonitor/readings/capture/",
                        {},
                    )
                    await this.load()
                    await this.selectReading(response.data)
                } catch (e) {
                    this.errormsg = e?.response?.data?.error || e?.message || String(e)
                    this.errored = true
                } finally {
                    this.captureLoading = false
                }
            },

            async selectReading(item) {
                this.selected = item
                // If recognition succeeded, prefill the manual boxes with the
                // automatic values.  An operator can therefore correct only a
                // wrong digit and submit both final values easily.
                this.manualTemperature = item?.recognized_temperature ?? ""
                this.manualHumidity = item?.recognized_humidity ?? ""

                if (this.selectedImageUrl) {
                    URL.revokeObjectURL(this.selectedImageUrl)
                    this.selectedImageUrl = null
                }

                try {
                    const response = await api.http.get(
                        `/facilitymonitor/readings/${item.id}/image/`,
                        { responseType: "blob" },
                    )
                    this.selectedImageUrl = URL.createObjectURL(response.data)
                } catch (e) {
                    this.errormsg = this.$t("facilitymonitor.image_load_failed")
                    this.errored = true
                }
            },

            async approveSelected() {
                if (!this.selected || !this.canchange) return
                try {
                    await api.http.post(
                        `/facilitymonitor/readings/${this.selected.id}/review/`,
                        { action: "approve" },
                    )
                    await this.load()
                    this.selected = null
                } catch (e) {
                    this.errormsg = e?.response?.data?.error || e?.message || String(e)
                    this.errored = true
                }
            },

            async submitManual() {
                if (!this.selected || !this.canchange) return
                if (this.manualTemperature === "" || this.manualHumidity === "") {
                    this.errormsg = this.$t("facilitymonitor.manual_both_required")
                    this.errored = true
                    return
                }
                try {
                    await api.http.post(
                        `/facilitymonitor/readings/${this.selected.id}/review/`,
                        {
                            action: "manual",
                            temperature: this.manualTemperature,
                            humidity: this.manualHumidity,
                        },
                    )
                    await this.load()
                    this.selected = null
                } catch (e) {
                    this.errormsg = e?.response?.data?.error || e?.message || String(e)
                    this.errored = true
                }
            },

            statusLabel(item) {
                return this.$t(`facilitymonitor.status_${item.status}`)
            },
        },

        async mounted() {
            this.checkPermissions()
            await this.load()
        },

        beforeUnmount() {
            if (this.selectedImageUrl) URL.revokeObjectURL(this.selectedImageUrl)
        },

        template: `
            <div id="facility-monitor-page" class="container-xl">
                <PageHeader :page-title="$t('facilitymonitor.menu_title')" />

                <div class="page-body">
                    <Alert
                        v-if="errored"
                        :message="errormsg"
                        :cols="true"
                        variant="danger"
                    />

                    <div class="card mb-3">
                        <div class="card-body d-flex gap-2 align-items-center">
                            <button
                                class="btn btn-primary"
                                :disabled="!canadd || captureLoading"
                                @click="captureNow"
                            >
                                {{ captureLoading ? $t('facilitymonitor.capturing') : $t('facilitymonitor.capture_now') }}
                            </button>
                            <button class="btn btn-outline-secondary" @click="load">
                                {{ $t('facilitymonitor.reload') }}
                            </button>
                            <span class="text-muted">
                                {{ $t('facilitymonitor.capture_help') }}
                            </span>
                        </div>
                    </div>

                    <div class="card mb-3">
                        <div class="card-header">
                            <h3 class="card-title">{{ $t('facilitymonitor.readings') }}</h3>
                        </div>
                        <div class="card-body p-0">
                            <div v-if="loading" class="p-4"><Loader /></div>
                            <div v-else class="table-responsive">
                                <table class="table table-vcenter card-table">
                                    <thead>
                                        <tr>
                                            <th>{{ $t('facilitymonitor.captured_at') }}</th>
                                            <th>{{ $t('facilitymonitor.auto_temperature') }}</th>
                                            <th>{{ $t('facilitymonitor.auto_humidity') }}</th>
                                            <th>{{ $t('facilitymonitor.approved_temperature') }}</th>
                                            <th>{{ $t('facilitymonitor.approved_humidity') }}</th>
                                            <th>{{ $t('facilitymonitor.status') }}</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="item in readings" :key="item.id">
                                            <td>{{ item.captured_at }}</td>
                                            <td>{{ item.recognized_temperature ?? '-' }}</td>
                                            <td>{{ item.recognized_humidity ?? '-' }}</td>
                                            <td>{{ item.approved_temperature ?? '-' }}</td>
                                            <td>{{ item.approved_humidity ?? '-' }}</td>
                                            <td>
                                                <span v-if="item.is_official" class="badge bg-green-lt me-1">
                                                    {{ $t('facilitymonitor.official') }}
                                                </span>
                                                {{ statusLabel(item) }}
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary" @click="selectReading(item)">
                                                    {{ $t('facilitymonitor.review') }}
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card" v-if="selected">
                        <div class="card-header">
                            <h3 class="card-title">
                                {{ $t('facilitymonitor.review') }} #{{ selected.id }}
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-7">
                                    <img
                                        v-if="selectedImageUrl"
                                        :src="selectedImageUrl"
                                        class="img-fluid border rounded"
                                        :alt="$t('facilitymonitor.source_image')"
                                    />
                                </div>
                                <div class="col-lg-5">
                                    <div class="mb-3">
                                        <strong>{{ $t('facilitymonitor.auto_temperature') }}:</strong>
                                        {{ selected.recognized_temperature ?? '-' }}
                                    </div>
                                    <div class="mb-3">
                                        <strong>{{ $t('facilitymonitor.auto_humidity') }}:</strong>
                                        {{ selected.recognized_humidity ?? '-' }}
                                    </div>

                                    <Alert
                                        v-if="selected.recognition_error"
                                        :message="selected.recognition_error"
                                        :cols="true"
                                        variant="warning"
                                    />

                                    <button
                                        class="btn btn-success mb-4"
                                        :disabled="!canchange || selected.recognized_temperature == null || selected.recognized_humidity == null"
                                        @click="approveSelected"
                                    >
                                        {{ $t('facilitymonitor.approve_auto') }}
                                    </button>

                                    <hr />
                                    <h4>{{ $t('facilitymonitor.manual_entry') }}</h4>
                                    <p class="text-muted">
                                        {{ $t('facilitymonitor.manual_help') }}
                                    </p>

                                    <div class="mb-3">
                                        <label class="form-label">{{ $t('facilitymonitor.temperature') }}</label>
                                        <input v-model="manualTemperature" type="number" step="0.01" class="form-control" />
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">{{ $t('facilitymonitor.humidity') }}</label>
                                        <input v-model="manualHumidity" type="number" step="0.01" class="form-control" />
                                    </div>
                                    <button
                                        class="btn btn-warning"
                                        :disabled="!canchange"
                                        @click="submitManual"
                                    >
                                        {{ $t('facilitymonitor.save_manual') }}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `,
    }
}
