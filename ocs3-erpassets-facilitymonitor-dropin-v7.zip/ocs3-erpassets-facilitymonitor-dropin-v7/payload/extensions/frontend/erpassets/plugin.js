// Reference-style OCS3 frontend extension entry point.
window.OCS_EXTENSIONS = window.OCS_EXTENSIONS || {}
console.info("[erpassets] plugin.js loaded")

window.OCS_EXTENSIONS["erpassets"] = {
    async register(api) {
        console.info("[erpassets] register() start")

        const en = await fetch("/extensions/erpassets/locales/en.json").then((r) => r.json())
        api.mergeI18n("en", en)

        // RC2 ships en/fr only. Keep zh-TW optional so a locale issue cannot
        // prevent the whole extension from registering.
        try {
            const zhTW = await fetch("/extensions/erpassets/locales/zh_TW.json").then((r) => r.json())
            api.mergeI18n("zh-TW", zhTW)
        } catch (e) {
            console.warn("[erpassets] zh-TW locale skipped", e)
        }

        const PageMod = await api.importModule(
            "/extensions/erpassets/components/ERPAssetsPage.js",
        )
        const AppLayout = api.getComponent("AppLayout")

        api.addRoute({
            path: "/inventory/erpassets",
            name: "ERPAssets",
            component: PageMod.createComponent(api),
            meta: { layout: AppLayout, requireAuth: true },
        })

        api.addMenuChildItem("inventory", {
            headerKey: "erpassets.menu_title",
            link: "/inventory/erpassets",
            route: "ERPAssets",
            column: "general",
        })

        api.registerSlot("inventory.asset.detail.afterAccountInfo", {
            component: async () => {
                const mod = await api.importModule(
                    "/extensions/erpassets/components/ERPAssetSlot.js",
                )
                return mod.createComponent(api)
            },
        })

        console.info("[erpassets] register() complete")
    },
}
