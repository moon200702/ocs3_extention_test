// Global ERP asset/reconciliation page, patterned after the official sample extension.
export function createComponent(api) {
    const PageHeader = api.getComponent("PageHeader")
    const Datatable = api.getComponent("Datatable")
    const Alert = api.getComponent("Alert")
    const Loader = api.getComponent("Loader")

    return {
        name: "ERPAssetsPage",
        components: { PageHeader, Datatable, Alert, Loader },

        data() {
            return {
                rowdata: [],
                rowheader: [
                    "asset_no",
                    "ocs_name",
                    "ocs_serial",
                    "erp_serial",
                    "reconciliation_status",
                    "department",
                    "custodian",
                    "location",
                    "status",
                    "last_sync",
                ],
                loading: false,
                errored: false,
                errormsg: null,
                integrationConfig: null,
                canview: false,
            }
        },

        methods: {
            checkPermissions() {
                this.canview = api.hasPermissions(["erpassets_view_erpasset"])
                if (!this.canview) {
                    this.errored = true
                    this.errormsg = this.$t("erpassets.no_view_permission")
                }
            },

            async load() {
                if (!this.canview) return
                this.loading = true
                this.errored = false
                this.errormsg = null

                try {
                    const [assetsResponse, configResponse] = await Promise.all([
                        api.http.get("/erpassets/assets/"),
                        api.http.get("/erpassets/assets/integration-config/"),
                    ])

                    const assets = assetsResponse?.data?.results ?? assetsResponse?.data ?? []
                    this.rowdata = assets
                    this.integrationConfig = configResponse?.data ?? null
                } catch (e) {
                    this.errormsg = e?.response?.data?.error || e?.message || String(e)
                    this.errored = true
                } finally {
                    this.loading = false
                }
            },

            goToMatchedAsset({ field, item }) {
                if (field !== "ocs_name" || !item?.asset) return
                this.$router.push(`/inventory/asset/${item.asset}`)
            },
        },

        async mounted() {
            this.checkPermissions()
            await this.load()
        },

        template: `
            <div id="erpassets-page" class="container-xl">
                <PageHeader :page-title="$t('erpassets.menu_title')" />

                <div class="page-body">
                    <div class="card mb-3" v-if="integrationConfig">
                        <div class="card-body">
                            <div class="datagrid">
                                <div class="datagrid-item">
                                    <div class="datagrid-title">{{ $t('erpassets.api_base_url') }}</div>
                                    <div class="datagrid-content"><code>{{ integrationConfig.base_url }}</code></div>
                                </div>
                                <div class="datagrid-item">
                                    <div class="datagrid-title">{{ $t('erpassets.api_assets_endpoint') }}</div>
                                    <div class="datagrid-content"><code>{{ integrationConfig.assets_endpoint || '/' }}</code></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <Alert
                                v-if="errored"
                                :message="errormsg"
                                :cols="true"
                                variant="danger"
                            />

                            <div v-if="loading" class="ocs-loader">
                                <Loader />
                            </div>

                            <Datatable
                                v-else-if="canview"
                                id="erpassets-datatable"
                                :rowdata="rowdata"
                                :rowheader="rowheader"
                                title="erpassets/assets"
                                translationkey="erpassets."
                                is-sticky
                                :candelete="false"
                                :candeletemultiple="false"
                                :usecheckbox="false"
                                :clickablecells="['ocs_name']"
                                @cell-click="goToMatchedAsset"
                                @reload-datatable="load"
                            />
                        </div>
                    </div>
                </div>
            </div>
        `,
    }
}
