OCS3 ERP Assets + Facility Monitor drop-in installer v7

This package keeps the v6 ERP Assets integration and adds a new Facility Monitor
extension for the workflow discussed in the lab:

  OCS web button
    -> backend calls Camera API
    -> save original image + SHA-256
    -> run OpenCV seven-segment recognition
    -> save automatic temperature/humidity
    -> operator reviews the source image
    -> approve or manually enter/correct values

The OpenCV result is NEVER overwritten by human review; automatic and approved
values stay in separate DB fields for audit/regression use.

Install:

  ./install.sh ~/audit_your_device/ocsinventory-server-3

Preview without changing files:

  ./install.sh ~/audit_your_device/ocsinventory-server-3 --dry-run

IMPORTANT CONFIGURATION FILES
=============================

1. Camera API / credentials

   Read:
     facility-monitor.env.example

   Copy only the required values into the target OCS project's existing `.env`.
   The installer intentionally does NOT overwrite `.env`.

   The vendor-specific camera adapter is:
     extensions/backend/facilitymonitor/services/camera.py

   Search for:
     CAMERA API CONFIGURATION POINT
     CAMERA API CUSTOMIZATION POINT

2. OpenCV profile

   Edit:
     extensions/backend/facilitymonitor/profiles/profile.json

   It ships with `enabled: false` intentionally.  Until configured, Capture now
   will still save the image but recognition will be marked failed so an operator
   can type the values manually.

   Modes:
     auto_v3        current connected-component research recognizer
     fixed_segments calibrated A..G rectangles for fixed CCTV/device deployment

   Fixed-segment schema example:
     profiles/profile.fixed-segments.example.json

3. Detailed walkthrough

   FACILITY_MONITOR_SETUP.md

Persistence:

  Original evidence images are stored in Docker volume:
    ocsinventory-facility-evidence

  Reading metadata / recognition evidence / human review are stored in Postgres.

Build dependencies added to the backend image:

  opencv-python-headless==4.12.0.88
  numpy>=2,<3
  requests>=2.32,<3

Source/provenance notes:

  extensions/backend/facilitymonitor/SOURCES.md
