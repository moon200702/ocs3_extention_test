# OCS3 ERP Asset Integration Extension (MVP)

A test extension for OCS Inventory 3.0 Rework.

The goal is deliberately small:

```text
ERP / maintenance REST API
            |
            v
     OCS3 Extension API
            |
            +--> ERP asset administrative data
            +--> component asset records
            +--> maintenance history
            |
            v
       OCS Asset Detail
```

It does **not** modify OCS core inventory fields. OCS Agent remains authoritative
for observed hardware/OS/software data.

## What this MVP proves

1. An external system can write ERP data directly into an OCS3 extension.
2. `serial` can be used to reconcile an ERP asset with `InventoryBase`.
3. ERP data can appear directly on the existing OCS asset detail page.
4. Components and maintenance records can be modeled as one-to-many relations,
   instead of forcing them into Accountinfo key/value fields.

## Backend REST API

### ERP assets

```text
GET    /erpassets/assets/
POST   /erpassets/assets/
GET    /erpassets/assets/{id}/
PATCH  /erpassets/assets/{id}/
DELETE /erpassets/assets/{id}/

GET    /erpassets/assets/by-asset/?asset_id=<OCS asset id>

POST   /erpassets/assets/upsert-by-serial/
```

The last endpoint is the main test endpoint for ERP integration.

Example:

```json
{
  "serial": "PF3ABC123",
  "asset_no": "IT-000123",
  "department": "IT",
  "custodian": "Jack",
  "location": "Kaohsiung",
  "status": "In Use",
  "source_system": "ERP",
  "source_id": "12345"
}
```

The extension finds the OCS `InventoryBase` whose serial matches. It refuses:

- no match: HTTP 404
- multiple OCS assets with the same serial: HTTP 409

It never modifies `InventoryBase.serial`.

### Components

```text
GET/POST/PATCH/DELETE /erpassets/components/
```

Fields include ERP component asset number, ERP serial, OCS-observed serial and
a match status.

### Maintenance

```text
GET/POST/PATCH/DELETE /erpassets/maintenance/
```

Maintenance events have a stable external ID and may record old/new serials.

## Backend installation

Copy:

```bash
cp -r backend/erpassets \
  /path/to/ocsinventory-backend/extensions/
```

Then, following the current OCS3 extension lifecycle:

```bash
cd /path/to/ocsinventory-backend

python manage.py extensions install erpassets --enable
python manage.py extensions list
```

Restart all backend application server workers after enabling so the URL routes
are mounted.

## Frontend installation

Copy:

```bash
cp -r frontend/erpassets \
  /path/to/ocsinventory-frontend/public/extensions/
```

Refresh the frontend after the backend extension is enabled.

The frontend registers against the core slot:

```text
inventory.asset.detail.afterAccountInfo
```

so ERP data appears below Accountinfo on the existing asset detail page.

## Permissions

The API uses OCS/Django model permissions through `DefaultModelPermissions`.

For an ERP service account, grant only the permissions needed for this
extension, for example:

```text
erpassets_view_erpasset
erpassets_add_erpasset
erpassets_change_erpasset

erpassets_view_erpcomponent
erpassets_add_erpcomponent
erpassets_change_erpcomponent

erpassets_view_maintenanceevent
erpassets_add_maintenanceevent
erpassets_change_maintenanceevent
```

Avoid giving the ERP service account broad OCS administrative permissions.

## Quick test

Set:

```bash
export OCS_URL=http://ocs.example.local
export OCS_TOKEN='...'
```

Then:

```bash
./examples/upsert_asset.sh
```

Open the corresponding OCS asset detail page. The extension panel should show
the ERP asset record.

After obtaining the returned ERP extension record ID:

```bash
export ERP_ASSET_ID=1

./examples/create_component.sh
./examples/create_maintenance.sh
```

Reload the OCS asset detail page.

## Current intentional limitations

This is an MVP, not a finished CMDB.

- no ERP pull scheduler yet
- no webhook signature validation layer yet
- no automatic matching of OCS DIMM/NVMe inventory sections to ERP components
- no repair workflow/state machine
- no change-history table for ERP field changes
- no configurable reconciliation keys
- serial matching is case-insensitive exact matching only
- frontend is read-only
- the migration dependency assumes the current OCS3 rework app label
  `inventory_base`; if upstream migration names change before stable release,
  regenerate the extension migration against that release

These limitations are intentional. The first question to answer is whether
the OCS3 extension workflow itself is comfortable enough to keep building on.

## Suggested next iteration

If this MVP works well, the next useful step is:

```text
ERP API
  |
  +--> Asset master
  +--> Component assets
  +--> Maintenance tickets
            |
            v
     Extension sync job
            |
            v
OCS observed hardware serials
            |
            v
Reconciliation status/history
```

At that point, the extension becomes the integration/reconciliation layer
instead of using Accountinfo as a pseudo-database.
