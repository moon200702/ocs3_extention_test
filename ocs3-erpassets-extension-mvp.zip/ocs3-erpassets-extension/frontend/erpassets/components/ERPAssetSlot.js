export function createComponent(api) {
    const Alert = api.getComponent("Alert")

    return {
        name: "ERPAssetSlot",
        components: { Alert },
        props: {
            assetId: { type: [String, Number], default: null },
        },

        data() {
            return {
                loading: false,
                record: null,
                error: null,
            }
        },

        watch: {
            assetId: {
                immediate: true,
                handler: "load",
            },
        },

        methods: {
            async load() {
                if (!this.assetId) return

                this.loading = true
                this.error = null
                this.record = null

                try {
                    const { data } = await api.http.get(
                        "/erpassets/assets/by-asset/",
                        { params: { asset_id: this.assetId } },
                    )
                    this.record = data
                } catch (e) {
                    if (e?.response?.status !== 404) {
                        this.error = e?.response?.data?.error || e?.message || String(e)
                    }
                } finally {
                    this.loading = false
                }
            },
        },

        template: `
            <div class="mt-4">
                <div align="center">
                    <h2>{{ $t("erpassets.title") }}</h2>
                </div>

                <div v-if="loading" class="text-center py-3">
                    <b-spinner />
                </div>

                <Alert v-if="error" :message="error" variant="danger" />

                <div v-if="!loading && !record" class="alert alert-secondary">
                    {{ $t("erpassets.no_record") }}
                </div>

                <div v-if="record">
                    <div class="datagrid mb-4">
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.asset_no") }}</div>
                            <div class="datagrid-content">{{ record.asset_no }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.erp_serial") }}</div>
                            <div class="datagrid-content">{{ record.erp_serial }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.serial_match") }}</div>
                            <div class="datagrid-content">
                                <span v-if="record.serial_match === true" class="badge bg-success">MATCH</span>
                                <span v-else-if="record.serial_match === false" class="badge bg-danger">MISMATCH</span>
                                <span v-else class="badge bg-secondary">UNKNOWN</span>
                            </div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.department") }}</div>
                            <div class="datagrid-content">{{ record.department }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.custodian") }}</div>
                            <div class="datagrid-content">{{ record.custodian }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.location") }}</div>
                            <div class="datagrid-content">{{ record.location }}</div>
                        </div>
                        <div class="datagrid-item">
                            <div class="datagrid-title">{{ $t("erpassets.status") }}</div>
                            <div class="datagrid-content">{{ record.status }}</div>
                        </div>
                    </div>

                    <h3>{{ $t("erpassets.components") }}</h3>
                    <div class="table-responsive mb-4">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Slot</th>
                                    <th>ERP Asset No</th>
                                    <th>ERP Serial</th>
                                    <th>Observed Serial</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in record.components || []" :key="item.id">
                                    <td>{{ item.component_type }}</td>
                                    <td>{{ item.slot }}</td>
                                    <td>{{ item.erp_asset_no }}</td>
                                    <td>{{ item.erp_serial }}</td>
                                    <td>{{ item.observed_serial }}</td>
                                    <td>{{ item.match_status }}</td>
                                </tr>
                                <tr v-if="!(record.components || []).length">
                                    <td colspan="6">{{ $t("erpassets.no_components") }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <h3>{{ $t("erpassets.maintenance") }}</h3>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Opened</th>
                                    <th>Type</th>
                                    <th>Problem</th>
                                    <th>Action</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in record.maintenance_events || []" :key="item.id">
                                    <td>{{ item.external_id }}</td>
                                    <td>{{ item.opened_at }}</td>
                                    <td>{{ item.event_type }}</td>
                                    <td>{{ item.problem }}</td>
                                    <td>{{ item.action }}</td>
                                    <td>{{ item.status }}</td>
                                </tr>
                                <tr v-if="!(record.maintenance_events || []).length">
                                    <td colspan="6">{{ $t("erpassets.no_maintenance") }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `,
    }
}
