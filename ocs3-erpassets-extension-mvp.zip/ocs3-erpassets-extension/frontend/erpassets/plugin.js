window.OCS_EXTENSIONS = window.OCS_EXTENSIONS || {}

window.OCS_EXTENSIONS["erpassets"] = {
    async register(api) {
        const en = await fetch("/extensions/erpassets/locales/en.json").then((r) => r.json())
        api.mergeI18n("en", en)

        const zhTW = await fetch("/extensions/erpassets/locales/zh_TW.json").then((r) => r.json())
        api.mergeI18n("zh-TW", zhTW)

        api.registerSlot("inventory.asset.detail.afterAccountInfo", {
            component: async () => {
                const mod = await api.importModule(
                    "/extensions/erpassets/components/ERPAssetSlot.js"
                )
                return mod.createComponent(api)
            },
        })
    },
}
