from rest_framework import serializers
from rest_framework.serializers import ModelSerializer

from .models import ERPAsset, ERPComponent, MaintenanceEvent


def _norm(value):
    return (value or "").strip().upper()


class ERPAssetSerializer(ModelSerializer):
    ocs_name = serializers.CharField(source="asset.name", read_only=True)
    ocs_serial = serializers.CharField(source="asset.serial", read_only=True)
    ocs_uuid = serializers.CharField(source="asset.uuid", read_only=True)
    serial_match = serializers.SerializerMethodField()

    class Meta:
        model = ERPAsset
        fields = [
            "id",
            "asset",
            "ocs_name",
            "ocs_serial",
            "ocs_uuid",
            "asset_no",
            "erp_serial",
            "serial_match",
            "department",
            "custodian",
            "location",
            "status",
            "source_system",
            "source_id",
            "raw_data",
            "last_sync",
            "created_at",
        ]
        read_only_fields = [
            "id",
            "ocs_name",
            "ocs_serial",
            "ocs_uuid",
            "serial_match",
            "last_sync",
            "created_at",
        ]

    def get_serial_match(self, obj):
        if not obj.erp_serial or not obj.asset.serial:
            return None
        return _norm(obj.erp_serial) == _norm(obj.asset.serial)


class ERPComponentSerializer(ModelSerializer):
    parent_asset_no = serializers.CharField(
        source="erp_asset.asset_no", read_only=True
    )

    class Meta:
        model = ERPComponent
        fields = [
            "id",
            "erp_asset",
            "parent_asset_no",
            "component_type",
            "slot",
            "manufacturer",
            "model",
            "erp_asset_no",
            "erp_serial",
            "observed_serial",
            "match_status",
            "source_id",
            "raw_data",
            "last_sync",
        ]
        read_only_fields = ["id", "parent_asset_no", "last_sync"]


class MaintenanceEventSerializer(ModelSerializer):
    parent_asset_no = serializers.CharField(
        source="erp_asset.asset_no", read_only=True
    )

    class Meta:
        model = MaintenanceEvent
        fields = [
            "id",
            "erp_asset",
            "parent_asset_no",
            "external_id",
            "event_type",
            "opened_at",
            "closed_at",
            "problem",
            "action",
            "vendor",
            "technician",
            "old_serial",
            "new_serial",
            "component_asset_no",
            "status",
            "raw_data",
            "last_sync",
        ]
        read_only_fields = ["id", "parent_asset_no", "last_sync"]
