#!/bin/sh
OCS_URL="${OCS_URL:-http://localhost}"
OCS_TOKEN="${OCS_TOKEN:?set OCS_TOKEN}"
ERP_ASSET_ID="${ERP_ASSET_ID:?set ERP_ASSET_ID}"

curl -sS \
  -H "Authorization: Token ${OCS_TOKEN}" \
  -H "Content-Type: application/json" \
  -X POST \
  "${OCS_URL}/erpassets/components/" \
  -d "{
    \"erp_asset\": ${ERP_ASSET_ID},
    \"component_type\": \"NVMe\",
    \"slot\": \"M.2-1\",
    \"manufacturer\": \"Samsung\",
    \"model\": \"Example NVMe\",
    \"erp_asset_no\": \"SSD-00031\",
    \"erp_serial\": \"S6EXAMPLE\",
    \"observed_serial\": \"S6EXAMPLE\",
    \"match_status\": \"matched\"
  }"
