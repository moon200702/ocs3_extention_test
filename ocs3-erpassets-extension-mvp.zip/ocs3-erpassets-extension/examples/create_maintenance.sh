#!/bin/sh
OCS_URL="${OCS_URL:-http://localhost}"
OCS_TOKEN="${OCS_TOKEN:?set OCS_TOKEN}"
ERP_ASSET_ID="${ERP_ASSET_ID:?set ERP_ASSET_ID}"

curl -sS \
  -H "Authorization: Token ${OCS_TOKEN}" \
  -H "Content-Type: application/json" \
  -X POST \
  "${OCS_URL}/erpassets/maintenance/" \
  -d "{
    \"erp_asset\": ${ERP_ASSET_ID},
    \"external_id\": \"RMA-2026-0001\",
    \"event_type\": \"component_replace\",
    \"opened_at\": \"2026-09-21T09:00:00+08:00\",
    \"closed_at\": \"2026-09-21T11:00:00+08:00\",
    \"problem\": \"NVMe SMART warning\",
    \"action\": \"Replace NVMe SSD\",
    \"old_serial\": \"OLD-SERIAL\",
    \"new_serial\": \"NEW-SERIAL\",
    \"component_asset_no\": \"SSD-00031\",
    \"status\": \"closed\"
  }"
