#!/bin/sh
# OCS3 Knox token expected.
OCS_URL="${OCS_URL:-http://localhost}"
OCS_TOKEN="${OCS_TOKEN:?set OCS_TOKEN}"

curl -sS \
  -H "Authorization: Token ${OCS_TOKEN}" \
  -H "Content-Type: application/json" \
  -X POST \
  "${OCS_URL}/erpassets/assets/upsert-by-serial/" \
  -d '{
    "serial": "PF3ABC123",
    "asset_no": "IT-000123",
    "department": "IT",
    "custodian": "Jack",
    "location": "Kaohsiung",
    "status": "In Use",
    "source_system": "ERP",
    "source_id": "12345"
  }'
