OCS3 ERP Assets drop-in installer v5

Changes in v5:
- ERP endpoint defaults to http://10.194.115.43/data
- erp_sync accepts a direct JSON asset object as well as list/envelope responses
- backend optionally syncs ERP data at container start (default enabled, non-fatal)
- frontend plugin emits [erpassets] console logs to simplify loader debugging

Install:

  ./install.sh ~/audit_your_device/ocsinventory-server-3

The installer backs up only the files it manages under:

  <target>/.erpassets-backup/<timestamp>/

Other extensions are not removed.

Preview without changing files:

  ./install.sh ~/audit_your_device/ocsinventory-server-3 --dry-run

Disable automatic ERP sync if needed by setting in .env:

  ERP_SYNC_ON_START=False
